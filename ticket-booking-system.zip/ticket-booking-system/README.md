# Ticket Booking System

A web-based train ticket booking system built as a BCA mini project.
Customers search trains, choose seats on a live seat map, pay through a test payment gateway and get an
e-ticket. Administrators manage trains, classes and fares and view booking and revenue reports.

## Technologies

| Layer | Technology |
|---|---|
| Frontend | HTML5, CSS3, JavaScript, Bootstrap 5 |
| Backend | Java 17, Spring Boot 3 (REST APIs, Spring Data JPA, Validation, Scheduling) |
| Database | MySQL 8 (H2 in-memory for tests and quick demos) |
| Security | BCrypt password hashing, session login, role-based access (Customer / Admin) |
| Payment | Built-in mock gateway, or Razorpay Test Mode |
| Testing | JUnit 5, AssertJ, Postman collection |
| Dataset | Kaggle Indian Railways schedule and fare data + synthetic users and bookings |

## Project structure

```
ticket-booking-system/
├── pom.xml                       Maven build file (dependencies)
├── mvnw, mvnw.cmd                Maven wrapper (no separate Maven install needed)
├── dataset/
│   ├── prepare_dataset.py        Cleans the Kaggle CSV into dataset/trains.csv
│   └── README.md                 Dataset instructions
├── docs/
│   ├── TEST_CASES.md             Test case table for the report / presentation
│   ├── postman_collection.json   API tests for Postman
│   └── schema.sql                Reference database schema
└── src/
    ├── main/java/com/dsu/ticketbooking/
    │   ├── model/                Entities: User, Train, TrainClass, Booking, SeatReservation, Payment
    │   ├── repository/           Spring Data JPA repositories (database access)
    │   ├── service/              Business logic: booking, seat locking, payment, fares, reports, data loading
    │   ├── controller/           REST API endpoints
    │   ├── dto/                  Request / response objects
    │   ├── config/               Password encoder, session login helper
    │   └── exception/            Error handling (clean JSON error messages)
    ├── main/resources/
    │   ├── application.properties
    │   ├── data/sample_trains.csv   Bundled sample data (used if dataset/trains.csv is absent)
    │   └── static/               Frontend pages (index, seats, payment, ticket, my-bookings, admin ...)
    └── test/                     JUnit tests
```

## Prerequisites

1. **JDK 17 or newer** (check with `java -version`).
2. **MySQL 8** running locally (XAMPP/WAMP MySQL also works). Not needed for the quick H2 demo.
3. An internet connection the first time, so Maven can download the libraries.
4. Optional: IntelliJ IDEA or Eclipse, Python 3 with pandas for the dataset script, Postman.

## Run it

### Option A: quick demo, no MySQL (H2 in-memory database)

```
./mvnw spring-boot:run -Dspring-boot.run.profiles=h2        (macOS / Linux)
mvnw.cmd spring-boot:run -Dspring-boot.run.profiles=h2      (Windows)
```

Data is lost when the app stops, which is fine for a demo.

### Option B: with MySQL (recommended for the final demo)

1. Open `src/main/resources/application.properties` and set your MySQL username and password:
   ```
   spring.datasource.username=root
   spring.datasource.password=root
   ```
   (XAMPP's default is user `root` with an empty password.)
2. Start the app:
   ```
   ./mvnw spring-boot:run        (macOS / Linux)
   mvnw.cmd spring-boot:run      (Windows)
   ```
   The `ticket_booking` database and all tables are created automatically.

### Option C: IntelliJ IDEA / Eclipse

Open the folder as a Maven project, wait for dependencies to download, then run
`TicketBookingApplication.java`. To use H2, set the active profile to `h2` in the run configuration.

Then open **http://localhost:8080**

## Accounts created on first start

| Role | Email | Password |
|---|---|---|
| Admin | admin@tbs.com | admin123 |
| Customer | demo@tbs.com | demo123 |
| Synthetic customers | e.g. aarav.sharma@example.com | password123 |

## Loading the Kaggle dataset

See `dataset/README.md`. In short:

```
cd dataset
pip install pandas
python prepare_dataset.py <downloaded-kaggle-file>.csv --max-trains 300 --out trains.csv
```

Restart the app on an empty database. Without `dataset/trains.csv`, the bundled sample of 18 trains is used.
Good sample searches: **SBC → MAS**, **MAS → SBC**, **SBC → MYS**, **SBC → NDLS**.

## Payments

* **MOCK (default):** the payment page shows "Pay (success card)" and "Simulate declined card".
  Works offline, which is the safest option for a live demo.
* **Razorpay Test Mode:** create a free Razorpay account, switch the dashboard to Test Mode, generate API
  keys, then set:
  ```
  app.payment.mode=RAZORPAY
  app.razorpay.key-id=rzp_test_xxxxxxxx
  app.razorpay.key-secret=xxxxxxxxxxxx
  ```
  Pay with the test cards or UPI IDs listed in the Razorpay documentation. The server verifies Razorpay's
  HMAC-SHA256 signature before confirming a booking. No real money moves in test mode.

## Booking rules (application.properties)

| Setting | Default | Meaning |
|---|---|---|
| app.booking.hold-minutes | 10 | Minutes seats stay locked while the customer pays |
| app.booking.max-seats | 6 | Seats per booking |
| app.booking.service-fee-percent | 2 | Service fee added to the fare |
| app.seed.sample-bookings | true | Create synthetic customers and bookings for reports |

## How double booking is prevented

1. When the customer clicks *Proceed to pay*, each seat is saved as **LOCKED** with a deadline.
2. Payment success turns the seats **BOOKED**. Failure, cancellation or timeout deletes the rows, so the
   seats are free again. A scheduled job runs every minute to expire unpaid bookings.
3. The `seat_reservations` table has a **UNIQUE (train_class_id, travel_date, seat_no)** constraint, so
   even if two requests arrive at the same moment, the database accepts only one of them.

## Run the tests

```
./mvnw test          (Windows: mvnw.cmd test)
```

17 automated tests run on an in-memory database. See `docs/TEST_CASES.md` for the test case table.
For API testing, import `docs/postman_collection.json` into Postman.

## REST API summary

| Method | Endpoint | Purpose | Access |
|---|---|---|---|
| POST | /api/auth/register | Create account | Public |
| POST | /api/auth/login | Log in | Public |
| POST | /api/auth/logout | Log out | Logged in |
| GET | /api/auth/me | Current user | Public |
| GET | /api/stations | Station list | Public |
| GET | /api/trains/search?from=&to=&date= | Search trains with availability | Public |
| GET | /api/trains/classes/{id}/seats?date= | Seat map | Public |
| POST | /api/bookings | Create booking and lock seats | Customer |
| GET | /api/bookings | My bookings | Customer |
| GET | /api/bookings/{id} | Booking / e-ticket details | Owner or admin |
| PUT | /api/bookings/{id}/cancel | Cancel and refund | Owner |
| GET | /api/payments/config | Payment mode | Public |
| POST | /api/payments/{id}/mock | Mock payment | Owner |
| POST | /api/payments/{id}/razorpay/order | Create Razorpay order | Owner |
| POST | /api/payments/{id}/razorpay/verify | Verify Razorpay payment | Owner |
| GET | /api/admin/reports | Dashboard figures | Admin |
| GET | /api/admin/bookings | All bookings | Admin |
| GET/POST/PUT/DELETE | /api/admin/trains... | Manage trains | Admin |
| POST/PUT/DELETE | /api/admin/classes... | Manage classes and fares | Admin |

## Five-minute demo script

1. Log in as **demo@tbs.com**, search **SBC → MAS** for tomorrow.
2. Pick a class, select two seats and note the live fare breakdown.
3. Proceed to pay and point out the seat-hold countdown. Pay with the success card and show the e-ticket.
4. Open a second browser (or incognito), log in as another user, open the same class and date:
   the two seats are now grey (double booking prevented).
5. Show *My Bookings*, cancel the booking, and show the seats are free again.
6. Log in as **admin@tbs.com**: reports, all bookings, edit a fare, add a train.
7. Run `mvnw test` and show the tests passing.

## Troubleshooting

| Problem | Fix |
|---|---|
| `Access denied for user 'root'` | Fix the MySQL username/password in application.properties |
| `Communications link failure` | MySQL is not running; start it (XAMPP control panel) or use the h2 profile |
| Port 8080 already in use | Add `server.port=8081` to application.properties |
| Kaggle data not loaded | The database already had trains: drop the `ticket_booking` database and restart |
| Page looks unstyled | Bootstrap loads from a CDN, so the browser needs internet access |
| `mvnw: Permission denied` | Run `chmod +x mvnw` once |

## Limitations and future scope

The system books direct trains from origin to destination (intermediate stops are not modelled), uses one
coach per class, and simulates refunds. Natural extensions: QR-code tickets, a mobile app, live payment
gateway deployment, dynamic pricing, and multiple passengers with individual names per seat.
