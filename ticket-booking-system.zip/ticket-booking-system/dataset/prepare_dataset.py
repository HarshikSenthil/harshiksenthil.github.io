"""
prepare_dataset.py
------------------
Cleans a Kaggle Indian Railways CSV and converts it into dataset/trains.csv,
the format the Spring Boot application loads at start-up.

Recommended Kaggle dataset:
    "Indian Railways Schedule-Prices-Availability Data" (by bhavyarajdev)
    Any similar train CSV also works, as long as it has train number, train name,
    source/destination stations and either fares or distance.

Usage:
    pip install pandas
    python prepare_dataset.py path/to/kaggle_file.csv
    python prepare_dataset.py path/to/kaggle_file.csv --max-trains 300 --out trains.csv
    python prepare_dataset.py path/to/kaggle_file.csv --show-columns     (only list columns)

How it works:
    1. Detects the needed columns by name (edit COLUMN_CANDIDATES below if detection fails).
    2. Accepts fares in "long" format (one row per class with class + fare columns)
       or "wide" format (one column per class: SL, 3A, 2A, 1A, CC ...).
    3. If the file has no fares but has distance, it estimates fares per class from distance.
    4. Cleans the data: removes duplicates, missing values, invalid times and fares.
    5. Keeps the most useful trains (default 300) so the demo stays fast.
    6. Writes one row per train and class, plus a short cleaning report.
"""

import argparse
import re
import sys

import pandas as pd

# ---------------------------------------------------------------------------
# Column name candidates (lower-case, spaces/underscores ignored).
# If your Kaggle file uses other names, add them here.
# ---------------------------------------------------------------------------
COLUMN_CANDIDATES = {
    "train_number": ["trainnumber", "trainno", "train", "number", "trainid", "trainnum"],
    "train_name": ["trainname", "name"],
    "source_code": ["sourcestationcode", "fromstationcode", "sourcecode", "fromcode",
                    "stationfromcode", "source", "from", "fromstation", "sourcestation", "origin"],
    "source_name": ["sourcestationname", "fromstationname", "sourcename", "fromname", "originname"],
    "destination_code": ["destinationstationcode", "tostationcode", "destinationcode", "tocode",
                         "stationtocode", "destination", "to", "tostation", "destinationstation", "dest"],
    "destination_name": ["destinationstationname", "tostationname", "destinationname", "toname", "destname"],
    "departure_time": ["departuretime", "departure", "deptime", "starttime", "fromtime", "sourcedeparture"],
    "arrival_time": ["arrivaltime", "arrival", "arrtime", "endtime", "totime", "destinationarrival"],
    "duration": ["duration", "traveltime", "journeytime", "durationh"],
    "distance": ["distance", "distancekm", "km", "totaldistance"],
    "class_code": ["class", "classcode", "travelclass", "coachclass", "seatclass", "classtype"],
    "fare": ["fare", "price", "ticketprice", "totalfare", "amount", "cost"],
}

CLASS_CODES = ["1A", "2A", "3A", "3E", "SL", "CC", "EC", "2S", "EA", "FC"]

# Seats per class in this project's model (one coach per class keeps the seat map readable)
SEATS_PER_CLASS = {"1A": 24, "2A": 48, "3A": 64, "3E": 72, "SL": 72, "CC": 78, "EC": 56, "2S": 100, "EA": 56, "FC": 24}

# Rough rupees-per-km rates, used ONLY when the file has distance but no fares
RATE_PER_KM = {"SL": 0.55, "3A": 1.45, "2A": 2.10, "1A": 3.60, "CC": 1.30, "EC": 2.60, "2S": 0.30}
MIN_FARE = {"SL": 145, "3A": 410, "2A": 600, "1A": 1000, "CC": 250, "EC": 500, "2S": 60}

OUTPUT_COLUMNS = ["train_number", "train_name", "source_code", "source_name", "destination_code",
                  "destination_name", "departure_time", "arrival_time", "duration",
                  "class_code", "fare", "total_seats"]


def norm(name: str) -> str:
    return re.sub(r"[^a-z0-9]", "", str(name).lower())


def find_column(df: pd.DataFrame, key: str):
    lookup = {norm(c): c for c in df.columns}
    for candidate in COLUMN_CANDIDATES[key]:
        if candidate in lookup:
            return lookup[candidate]
    return None


def class_from_column(col: str):
    """'3A', 'fare_3a', '3A_price', 'SL Fare' -> '3A' / 'SL'."""
    n = norm(col).upper()
    for code in CLASS_CODES:
        if n == code or n in (f"FARE{code}", f"{code}FARE", f"PRICE{code}", f"{code}PRICE"):
            return code
    return None


def clean_time(value):
    if pd.isna(value):
        return None
    match = re.search(r"(\d{1,2})[:.](\d{2})", str(value))
    if not match:
        return None
    h, m = int(match.group(1)), int(match.group(2))
    if 0 <= h <= 23 and 0 <= m <= 59:
        return f"{h:02d}:{m:02d}"
    return None


def clean_code(value):
    if pd.isna(value):
        return None
    text = str(value).strip().upper()
    code = re.sub(r"[^A-Z0-9]", "", text)
    return code[:10] if code else None


def clean_number(value):
    if pd.isna(value):
        return None
    digits = re.sub(r"\D", "", str(value).split(".")[0])
    return digits[:10] if digits else None


def to_float(value):
    if pd.isna(value):
        return None
    match = re.search(r"\d+(\.\d+)?", str(value).replace(",", ""))
    return float(match.group(0)) if match else None


def estimate_fare(code: str, distance_km: float):
    if distance_km is None or code not in RATE_PER_KM:
        return None
    return round(max(MIN_FARE[code], distance_km * RATE_PER_KM[code]), 0)


def main():
    parser = argparse.ArgumentParser(description="Prepare a Kaggle railway CSV for the Ticket Booking System")
    parser.add_argument("input", help="Kaggle CSV file")
    parser.add_argument("--out", default="trains.csv", help="output file (default: trains.csv)")
    parser.add_argument("--max-trains", type=int, default=300, help="maximum trains to keep (default: 300)")
    parser.add_argument("--show-columns", action="store_true", help="only print the columns and exit")
    args = parser.parse_args()

    df = pd.read_csv(args.input, low_memory=False)
    print(f"Loaded {len(df):,} rows and {len(df.columns)} columns from {args.input}")
    if args.show_columns:
        for c in df.columns:
            print("  -", c)
        return

    cols = {key: find_column(df, key) for key in COLUMN_CANDIDATES}
    print("\nDetected columns:")
    for key, col in cols.items():
        print(f"  {key:<17} -> {col}")

    for required in ["train_number", "source_code", "destination_code"]:
        if cols[required] is None:
            sys.exit(f"\nERROR: could not find a column for '{required}'. "
                     f"Run with --show-columns and add the name to COLUMN_CANDIDATES.")

    # ------------------------------------------------------------- base train columns
    base = pd.DataFrame({
        "train_number": df[cols["train_number"]].map(clean_number),
        "train_name": df[cols["train_name"]].astype(str).str.strip().str.title() if cols["train_name"] else None,
        "source_code": df[cols["source_code"]].map(clean_code),
        "source_name": df[cols["source_name"]].astype(str).str.strip().str.title() if cols["source_name"] else None,
        "destination_code": df[cols["destination_code"]].map(clean_code),
        "destination_name": df[cols["destination_name"]].astype(str).str.strip().str.title() if cols["destination_name"] else None,
        "departure_time": df[cols["departure_time"]].map(clean_time) if cols["departure_time"] else None,
        "arrival_time": df[cols["arrival_time"]].map(clean_time) if cols["arrival_time"] else None,
        "duration": df[cols["duration"]].astype(str).str.strip() if cols["duration"] else None,
        "distance": df[cols["distance"]].map(to_float) if cols["distance"] else None,
    })
    if cols["train_name"] is None:
        base["train_name"] = "Train " + base["train_number"].astype(str)

    # ------------------------------------------------------------- fares: long, wide or estimated
    wide_cols = {c: class_from_column(c) for c in df.columns if class_from_column(c)}
    if cols["class_code"] and cols["fare"]:
        fare_format = "long (one row per class)"
        base["class_code"] = df[cols["class_code"]].astype(str).str.upper().str.strip()
        base["fare"] = df[cols["fare"]].map(to_float)
        rows = base
    elif wide_cols:
        fare_format = "wide (one column per class: " + ", ".join(sorted(set(wide_cols.values()))) + ")"
        parts = []
        for col, code in wide_cols.items():
            part = base.copy()
            part["class_code"] = code
            part["fare"] = df[col].map(to_float)
            parts.append(part)
        rows = pd.concat(parts, ignore_index=True)
    elif cols["distance"]:
        fare_format = "estimated from distance (no fare columns found)"
        parts = []
        for code in ["SL", "3A", "2A"]:
            part = base.copy()
            part["class_code"] = code
            part["fare"] = part["distance"].map(lambda d, c=code: estimate_fare(c, d))
            parts.append(part)
        rows = pd.concat(parts, ignore_index=True)
    else:
        sys.exit("\nERROR: no fare, class or distance columns found. Add the names to COLUMN_CANDIDATES.")
    print(f"\nFare format: {fare_format}")

    # ------------------------------------------------------------- cleaning
    before = len(rows)
    rows = rows.dropna(subset=["train_number", "source_code", "destination_code", "class_code", "fare"])
    after_missing = len(rows)
    rows = rows[rows["class_code"].isin(CLASS_CODES)]
    after_class = len(rows)
    rows = rows[(rows["fare"] > 0) & (rows["fare"] < 20000)]
    after_fare = len(rows)
    rows = rows[rows["source_code"] != rows["destination_code"]]
    # the same train + class can appear many times (e.g. one row per date): keep the median fare
    first = rows.groupby(["train_number", "class_code"], as_index=False).first()
    median = rows.groupby(["train_number", "class_code"], as_index=False)["fare"].median()
    rows = first.drop(columns=["fare"]).merge(median, on=["train_number", "class_code"])
    # one route per train number
    route = rows.groupby("train_number", as_index=False)[["source_code", "destination_code"]].first()
    rows = rows.drop(columns=["source_code", "destination_code"]).merge(route, on="train_number")

    # ------------------------------------------------------------- keep the busiest stations' trains
    station_counts = pd.concat([rows["source_code"], rows["destination_code"]]).value_counts()
    trains = rows.drop_duplicates("train_number").copy()
    trains["score"] = trains["source_code"].map(station_counts) + trains["destination_code"].map(station_counts)
    keep = trains.sort_values("score", ascending=False).head(args.max_trains)["train_number"]
    rows = rows[rows["train_number"].isin(keep)].copy()

    # ------------------------------------------------------------- final columns
    rows["fare"] = rows["fare"].round(2)
    rows["total_seats"] = rows["class_code"].map(SEATS_PER_CLASS).fillna(60).astype(int)
    for col in ["source_name", "destination_name"]:
        rows[col] = rows[col].where(rows[col].notna() & (rows[col].astype(str) != "None") & (rows[col].astype(str) != "Nan"),
                                    rows[col.replace("_name", "_code")])
    rows["duration"] = rows["duration"].where(rows["duration"].astype(str).str.lower() != "nan", None)
    rows = rows[OUTPUT_COLUMNS].sort_values(["train_number", "fare"])
    rows.to_csv(args.out, index=False)

    print("\nCleaning report")
    print(f"  rows after reshaping          : {before:,}")
    print(f"  removed (missing values)      : {before - after_missing:,}")
    print(f"  removed (unknown class)       : {after_missing - after_class:,}")
    print(f"  removed (invalid fare)        : {after_class - after_fare:,}")
    print(f"  trains kept                   : {rows['train_number'].nunique():,}")
    print(f"  train-class rows written      : {len(rows):,}")
    print(f"  stations covered              : {pd.concat([rows['source_code'], rows['destination_code']]).nunique():,}")
    print(f"\nSaved {args.out}. Copy it to the project's dataset/ folder and restart the app on an empty database.")


if __name__ == "__main__":
    main()
