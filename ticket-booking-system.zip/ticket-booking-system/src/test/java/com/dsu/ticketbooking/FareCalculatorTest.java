package com.dsu.ticketbooking;

import com.dsu.ticketbooking.service.FareCalculator;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

/** Unit tests: no database or Spring needed. */
class FareCalculatorTest {

    private final FareCalculator calculator = new FareCalculator(new BigDecimal("2"));

    @Test
    @DisplayName("UT01 - fare x seats plus 2% service fee")
    void calculatesTotal() {
        FareCalculator.FareBreakdown f = calculator.calculate(new BigDecimal("500.00"), 3);
        assertThat(f.subtotal()).isEqualByComparingTo("1500.00");
        assertThat(f.serviceFee()).isEqualByComparingTo("30.00");
        assertThat(f.total()).isEqualByComparingTo("1530.00");
    }

    @Test
    @DisplayName("UT02 - service fee is rounded to 2 decimals")
    void roundsFee() {
        FareCalculator.FareBreakdown f = calculator.calculate(new BigDecimal("333.33"), 1);
        assertThat(f.serviceFee()).isEqualByComparingTo("6.67");
        assertThat(f.total()).isEqualByComparingTo("340.00");
    }

    @Test
    @DisplayName("UT03 - zero seats is rejected")
    void rejectsZeroSeats() {
        assertThatThrownBy(() -> calculator.calculate(new BigDecimal("100"), 0))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    @DisplayName("UT04 - negative fare is rejected")
    void rejectsNegativeFare() {
        assertThatThrownBy(() -> calculator.calculate(new BigDecimal("-1"), 1))
                .isInstanceOf(IllegalArgumentException.class);
    }
}
