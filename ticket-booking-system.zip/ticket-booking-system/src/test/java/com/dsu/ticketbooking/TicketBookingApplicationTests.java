package com.dsu.ticketbooking;

import com.dsu.ticketbooking.repository.TrainRepository;
import com.dsu.ticketbooking.repository.UserRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
class TicketBookingApplicationTests {

    @Autowired private TrainRepository trainRepository;
    @Autowired private UserRepository userRepository;

    @Test
    void contextLoadsAndSampleDataIsImported() {
        assertThat(trainRepository.count()).isPositive();
        assertThat(userRepository.findByEmailIgnoreCase("admin@tbs.com")).isPresent();
    }
}
