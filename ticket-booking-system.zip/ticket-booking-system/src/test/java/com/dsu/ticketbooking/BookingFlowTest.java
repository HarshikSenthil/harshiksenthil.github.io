package com.dsu.ticketbooking;

import com.dsu.ticketbooking.dto.BookingDto;
import com.dsu.ticketbooking.dto.BookingRequest;
import com.dsu.ticketbooking.dto.RegisterRequest;
import com.dsu.ticketbooking.dto.TrainResult;
import com.dsu.ticketbooking.exception.ApiException;
import com.dsu.ticketbooking.model.*;
import com.dsu.ticketbooking.repository.BookingRepository;
import com.dsu.ticketbooking.repository.PaymentRepository;
import com.dsu.ticketbooking.repository.TrainClassRepository;
import com.dsu.ticketbooking.service.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

/**
 * Integration tests on an in-memory H2 database loaded with the bundled sample trains.
 * Each test uses its own travel date so tests never share seats.
 */
@SpringBootTest
class BookingFlowTest {

    private static final AtomicInteger DAY = new AtomicInteger(30);

    @Autowired private AuthService authService;
    @Autowired private TrainService trainService;
    @Autowired private BookingService bookingService;
    @Autowired private PaymentService paymentService;
    @Autowired private SeatService seatService;
    @Autowired private TrainClassRepository classRepository;
    @Autowired private BookingRepository bookingRepository;
    @Autowired private PaymentRepository paymentRepository;

    private User newUser() {
        String email = "c-" + UUID.randomUUID().toString().substring(0, 8) + "@test.com";
        return authService.register(new RegisterRequest("Customer", email, "secret123"));
    }

    private LocalDate freshDate() {
        return LocalDate.now().plusDays(DAY.incrementAndGet());
    }

    private Long anyClassId() {
        return classRepository.findAll().get(0).getId();
    }

    @Test
    @DisplayName("TC03 - search returns trains with seat availability")
    void searchWorks() {
        TrainResult train = trainService.adminList(null).get(0);
        String from = train.sourceCode();
        String to = train.destinationCode();
        List<TrainResult> results = trainService.search(from, to, LocalDate.now().plusDays(1));
        assertThat(results).isNotEmpty();
        assertThat(results.get(0).classes()).isNotEmpty();
        assertThat(results.get(0).classes().get(0).available()).isPositive();
    }

    @Test
    @DisplayName("TC10 - search with a past date is rejected")
    void searchPastDate() {
        assertThatThrownBy(() -> trainService.search("SBC", "MAS", LocalDate.now().minusDays(1)))
                .isInstanceOf(ApiException.class)
                .extracting("status").isEqualTo(HttpStatus.BAD_REQUEST);
    }

    @Test
    @DisplayName("TC04 - booking + successful payment confirms the booking and books the seats")
    void bookAndPay() {
        User user = newUser();
        Long classId = anyClassId();
        LocalDate date = freshDate();
        BookingDto pending = bookingService.create(user, new BookingRequest(classId, date, List.of(1, 2), "Ravi Kumar"));
        assertThat(pending.status()).isEqualTo("PENDING");
        assertThat(pending.holdSecondsRemaining()).isPositive();

        BookingDto confirmed = paymentService.payMock(user, pending.id(), true);
        assertThat(confirmed.status()).isEqualTo("CONFIRMED");
        assertThat(seatService.unavailableSeats(classId, date)).containsExactly(1, 2);
        assertThat(paymentRepository.findByBookingId(pending.id()))
                .extracting(Payment::getStatus).containsExactly(PaymentStatus.SUCCESS);
    }

    @Test
    @DisplayName("TC05 - the same seat cannot be booked twice (double-booking prevention)")
    void doubleBookingRejected() {
        Long classId = anyClassId();
        LocalDate date = freshDate();
        bookingService.create(newUser(), new BookingRequest(classId, date, List.of(5), "First Customer"));

        User second = newUser();
        assertThatThrownBy(() -> bookingService.create(second, new BookingRequest(classId, date, List.of(5, 6), "Second")))
                .isInstanceOf(ApiException.class)
                .extracting("status").isEqualTo(HttpStatus.CONFLICT);
        // the failed attempt must not leave seat 6 locked
        assertThat(seatService.unavailableSeats(classId, date)).containsExactly(5);
    }

    @Test
    @DisplayName("TC06 - failed payment releases the seats")
    void failedPaymentReleasesSeats() {
        User user = newUser();
        Long classId = anyClassId();
        LocalDate date = freshDate();
        BookingDto pending = bookingService.create(user, new BookingRequest(classId, date, List.of(10), "Ravi"));

        BookingDto failed = paymentService.payMock(user, pending.id(), false);
        assertThat(failed.status()).isEqualTo("FAILED");
        assertThat(seatService.unavailableSeats(classId, date)).isEmpty();
    }

    @Test
    @DisplayName("TC07 - cancelling a confirmed booking releases seats and refunds")
    void cancelBooking() {
        User user = newUser();
        Long classId = anyClassId();
        LocalDate date = freshDate();
        BookingDto pending = bookingService.create(user, new BookingRequest(classId, date, List.of(3), "Ravi"));
        paymentService.payMock(user, pending.id(), true);

        BookingDto cancelled = bookingService.cancel(user, pending.id());
        assertThat(cancelled.status()).isEqualTo("CANCELLED");
        assertThat(seatService.unavailableSeats(classId, date)).isEmpty();
        assertThat(paymentRepository.findByBookingId(pending.id()))
                .extracting(Payment::getStatus).containsExactly(PaymentStatus.REFUNDED);
    }

    @Test
    @DisplayName("TC11 - unpaid booking expires after the hold time and seats are released")
    void holdExpires() {
        User user = newUser();
        Long classId = anyClassId();
        LocalDate date = freshDate();
        BookingDto pending = bookingService.create(user, new BookingRequest(classId, date, List.of(7), "Ravi"));

        Booking booking = bookingRepository.findById(pending.id()).orElseThrow();
        booking.setHoldExpiresAt(LocalDateTime.now().minusMinutes(1));
        bookingRepository.save(booking);

        bookingService.expireStaleHolds();
        assertThat(bookingRepository.findById(pending.id()).orElseThrow().getStatus()).isEqualTo(BookingStatus.EXPIRED);
        assertThat(seatService.unavailableSeats(classId, date)).isEmpty();
    }

    @Test
    @DisplayName("TC12 - more than the maximum number of seats is rejected")
    void tooManySeats() {
        assertThatThrownBy(() -> bookingService.create(newUser(),
                new BookingRequest(anyClassId(), freshDate(), List.of(1, 2, 3, 4, 5, 6, 7), "Ravi")))
                .isInstanceOf(ApiException.class)
                .extracting("status").isEqualTo(HttpStatus.BAD_REQUEST);
    }

    @Test
    @DisplayName("TC13 - a customer cannot view another customer's booking")
    void cannotSeeOthersBooking() {
        BookingDto b = bookingService.create(newUser(), new BookingRequest(anyClassId(), freshDate(), List.of(1), "Ravi"));
        User stranger = newUser();
        assertThatThrownBy(() -> bookingService.get(stranger, b.id()))
                .isInstanceOf(ApiException.class)
                .extracting("status").isEqualTo(HttpStatus.NOT_FOUND);
    }
}
