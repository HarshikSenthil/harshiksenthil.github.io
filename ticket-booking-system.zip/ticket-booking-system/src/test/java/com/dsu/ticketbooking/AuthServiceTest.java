package com.dsu.ticketbooking;

import com.dsu.ticketbooking.dto.RegisterRequest;
import com.dsu.ticketbooking.exception.ApiException;
import com.dsu.ticketbooking.model.User;
import com.dsu.ticketbooking.service.AuthService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;

import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

@SpringBootTest
class AuthServiceTest {

    @Autowired
    private AuthService authService;

    private String uniqueEmail() {
        return "user-" + UUID.randomUUID().toString().substring(0, 8) + "@test.com";
    }

    @Test
    @DisplayName("TC01 - register and log in with correct credentials")
    void registerAndLogin() {
        String email = uniqueEmail();
        User created = authService.register(new RegisterRequest("Test User", email, "secret123"));
        assertThat(created.getPasswordHash()).isNotEqualTo("secret123"); // stored hashed
        User loggedIn = authService.login(email.toUpperCase(), "secret123");
        assertThat(loggedIn.getId()).isEqualTo(created.getId());
    }

    @Test
    @DisplayName("TC02 - wrong password is rejected")
    void wrongPassword() {
        String email = uniqueEmail();
        authService.register(new RegisterRequest("Test User", email, "secret123"));
        assertThatThrownBy(() -> authService.login(email, "wrong-password"))
                .isInstanceOf(ApiException.class)
                .extracting("status").isEqualTo(HttpStatus.UNAUTHORIZED);
    }

    @Test
    @DisplayName("TC09 - duplicate email cannot register twice")
    void duplicateEmail() {
        String email = uniqueEmail();
        authService.register(new RegisterRequest("Test User", email, "secret123"));
        assertThatThrownBy(() -> authService.register(new RegisterRequest("Other", email, "secret456")))
                .isInstanceOf(ApiException.class)
                .extracting("status").isEqualTo(HttpStatus.CONFLICT);
    }
}
