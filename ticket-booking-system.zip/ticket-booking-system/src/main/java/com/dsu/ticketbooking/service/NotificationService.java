package com.dsu.ticketbooking.service;

import com.dsu.ticketbooking.model.Booking;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

/**
 * Notification module. Always writes to the log; also sends an e-mail when
 * app.mail.enabled=true and spring.mail.* settings are configured.
 */
@Service
public class NotificationService {

    private static final Logger log = LoggerFactory.getLogger(NotificationService.class);

    private final ObjectProvider<JavaMailSender> mailSender;
    private final boolean enabled;
    private final String from;

    public NotificationService(ObjectProvider<JavaMailSender> mailSender,
                               @Value("${app.mail.enabled:false}") boolean enabled,
                               @Value("${app.mail.from:no-reply@ticketbooking.local}") String from) {
        this.mailSender = mailSender;
        this.enabled = enabled;
        this.from = from;
    }

    public void bookingConfirmed(Booking b) {
        String text = "Dear " + b.getUser().getName() + ",\n\n"
                + "Your booking is confirmed.\n"
                + "PNR: " + b.getPnr() + "\n"
                + "Train: " + b.getTrainClass().getTrain().getTrainNumber() + " " + b.getTrainClass().getTrain().getTrainName() + "\n"
                + "Date: " + b.getTravelDate() + "   Class: " + b.getTrainClass().getClassCode() + "\n"
                + "Seats: " + b.getSeatNumbers() + "\n"
                + "Amount paid: Rs. " + b.getTotalAmount() + "\n\n"
                + "Happy journey!\nTicket Booking System";
        send(b.getUser().getEmail(), "Booking confirmed - PNR " + b.getPnr(), text);
    }

    public void bookingCancelled(Booking b) {
        String text = "Dear " + b.getUser().getName() + ",\n\n"
                + "Your booking with PNR " + b.getPnr() + " has been cancelled.\n"
                + "A refund of Rs. " + b.getTotalAmount() + " has been initiated (test mode).\n\nTicket Booking System";
        send(b.getUser().getEmail(), "Booking cancelled - PNR " + b.getPnr(), text);
    }

    private void send(String to, String subject, String text) {
        log.info("NOTIFICATION to {} | {}", to, subject);
        if (!enabled) {
            return;
        }
        JavaMailSender sender = mailSender.getIfAvailable();
        if (sender == null) {
            log.warn("app.mail.enabled=true but spring.mail.host is not configured; e-mail skipped");
            return;
        }
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(from);
            message.setTo(to);
            message.setSubject(subject);
            message.setText(text);
            sender.send(message);
        } catch (Exception e) {
            // a failed e-mail must never break the booking itself
            log.warn("Could not send e-mail to {}: {}", to, e.getMessage());
        }
    }
}
