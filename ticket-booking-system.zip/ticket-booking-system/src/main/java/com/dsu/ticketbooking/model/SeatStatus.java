package com.dsu.ticketbooking.model;

public enum SeatStatus {
    LOCKED, BOOKED
}
