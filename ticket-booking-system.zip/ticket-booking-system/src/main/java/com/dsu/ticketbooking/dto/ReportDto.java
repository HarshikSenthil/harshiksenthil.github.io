package com.dsu.ticketbooking.dto;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

public record ReportDto(long totalBookings, long confirmed, long cancelled, long failedOrExpired, long pending,
                        BigDecimal revenue, BigDecimal refunded, long totalTrains, long totalUsers,
                        List<Map<String, Object>> topTrains, List<Map<String, Object>> bookingsByClass) {
}
