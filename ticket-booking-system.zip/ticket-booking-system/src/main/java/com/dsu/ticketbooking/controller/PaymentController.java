package com.dsu.ticketbooking.controller;

import com.dsu.ticketbooking.config.CurrentUser;
import com.dsu.ticketbooking.dto.BookingDto;
import com.dsu.ticketbooking.dto.MockPaymentRequest;
import com.dsu.ticketbooking.dto.RazorpayVerifyRequest;
import com.dsu.ticketbooking.service.PaymentService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/payments")
public class PaymentController {

    private final PaymentService paymentService;
    private final CurrentUser currentUser;

    public PaymentController(PaymentService paymentService, CurrentUser currentUser) {
        this.paymentService = paymentService;
        this.currentUser = currentUser;
    }

    /** Tells the payment page whether to show the mock buttons or Razorpay Checkout. */
    @GetMapping("/config")
    public Map<String, Object> config() {
        return paymentService.config();
    }

    @PostMapping("/{bookingId}/mock")
    public BookingDto mock(@PathVariable Long bookingId, @Valid @RequestBody MockPaymentRequest body,
                           HttpServletRequest request) {
        return paymentService.payMock(currentUser.require(request), bookingId, body.success());
    }

    @PostMapping("/{bookingId}/razorpay/order")
    public Map<String, Object> razorpayOrder(@PathVariable Long bookingId, HttpServletRequest request) {
        return paymentService.createRazorpayOrder(currentUser.require(request), bookingId);
    }

    @PostMapping("/{bookingId}/razorpay/verify")
    public BookingDto razorpayVerify(@PathVariable Long bookingId, @Valid @RequestBody RazorpayVerifyRequest body,
                                     HttpServletRequest request) {
        return paymentService.verifyRazorpay(currentUser.require(request), bookingId,
                body.razorpayOrderId(), body.razorpayPaymentId(), body.razorpaySignature());
    }
}
