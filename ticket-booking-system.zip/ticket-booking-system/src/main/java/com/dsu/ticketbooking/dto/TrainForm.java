package com.dsu.ticketbooking.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import java.util.List;

public record TrainForm(
        @NotBlank(message = "is required") @Size(max = 10) String trainNumber,
        @NotBlank(message = "is required") @Size(max = 120) String trainName,
        @NotBlank(message = "is required") @Size(max = 10) String sourceCode,
        @Size(max = 100) String sourceName,
        @NotBlank(message = "is required") @Size(max = 10) String destinationCode,
        @Size(max = 100) String destinationName,
        @Pattern(regexp = "^([01]\\d|2[0-3]):[0-5]\\d$", message = "must be HH:mm") String departureTime,
        @Pattern(regexp = "^([01]\\d|2[0-3]):[0-5]\\d$", message = "must be HH:mm") String arrivalTime,
        @Size(max = 20) String duration,
        List<@Valid ClassForm> classes) {
}
