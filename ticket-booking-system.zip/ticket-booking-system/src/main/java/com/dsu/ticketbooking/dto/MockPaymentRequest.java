package com.dsu.ticketbooking.dto;

import jakarta.validation.constraints.NotNull;

/** success=true simulates a successful test card, false simulates a declined card. */
public record MockPaymentRequest(@NotNull(message = "is required") Boolean success) {
}
