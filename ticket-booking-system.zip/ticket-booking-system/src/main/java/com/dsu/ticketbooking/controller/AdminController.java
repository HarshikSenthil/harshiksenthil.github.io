package com.dsu.ticketbooking.controller;

import com.dsu.ticketbooking.config.CurrentUser;
import com.dsu.ticketbooking.dto.*;
import com.dsu.ticketbooking.service.BookingService;
import com.dsu.ticketbooking.service.ReportService;
import com.dsu.ticketbooking.service.TrainService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/** Admin module: every endpoint checks for the ADMIN role. */
@RestController
@RequestMapping("/api/admin")
public class AdminController {

    private final CurrentUser currentUser;
    private final ReportService reportService;
    private final BookingService bookingService;
    private final TrainService trainService;

    public AdminController(CurrentUser currentUser, ReportService reportService,
                           BookingService bookingService, TrainService trainService) {
        this.currentUser = currentUser;
        this.reportService = reportService;
        this.bookingService = bookingService;
        this.trainService = trainService;
    }

    @GetMapping("/reports")
    public ReportDto reports(HttpServletRequest request) {
        currentUser.requireAdmin(request);
        return reportService.summary();
    }

    @GetMapping("/bookings")
    public List<BookingDto> bookings(HttpServletRequest request) {
        currentUser.requireAdmin(request);
        return bookingService.allBookings();
    }

    @GetMapping("/trains")
    public List<TrainResult> trains(@RequestParam(required = false) String q, HttpServletRequest request) {
        currentUser.requireAdmin(request);
        return trainService.adminList(q);
    }

    @PostMapping("/trains")
    public ResponseEntity<TrainResult> createTrain(@Valid @RequestBody TrainForm form, HttpServletRequest request) {
        currentUser.requireAdmin(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(trainService.createTrain(form));
    }

    @PutMapping("/trains/{id}")
    public TrainResult updateTrain(@PathVariable Long id, @Valid @RequestBody TrainForm form, HttpServletRequest request) {
        currentUser.requireAdmin(request);
        return trainService.updateTrain(id, form);
    }

    @DeleteMapping("/trains/{id}")
    public ResponseEntity<Void> deleteTrain(@PathVariable Long id, HttpServletRequest request) {
        currentUser.requireAdmin(request);
        trainService.deleteTrain(id);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/trains/{id}/classes")
    public TrainResult addClass(@PathVariable Long id, @Valid @RequestBody ClassForm form, HttpServletRequest request) {
        currentUser.requireAdmin(request);
        return trainService.addClass(id, form);
    }

    @PutMapping("/classes/{classId}")
    public ClassInfo updateClass(@PathVariable Long classId, @Valid @RequestBody ClassForm form, HttpServletRequest request) {
        currentUser.requireAdmin(request);
        return trainService.updateClass(classId, form);
    }

    @DeleteMapping("/classes/{classId}")
    public ResponseEntity<Void> deleteClass(@PathVariable Long classId, HttpServletRequest request) {
        currentUser.requireAdmin(request);
        trainService.deleteClass(classId);
        return ResponseEntity.noContent().build();
    }
}
