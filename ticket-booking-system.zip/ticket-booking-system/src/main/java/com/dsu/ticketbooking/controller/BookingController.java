package com.dsu.ticketbooking.controller;

import com.dsu.ticketbooking.config.CurrentUser;
import com.dsu.ticketbooking.dto.BookingDto;
import com.dsu.ticketbooking.dto.BookingRequest;
import com.dsu.ticketbooking.service.BookingService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/bookings")
public class BookingController {

    private final BookingService bookingService;
    private final CurrentUser currentUser;

    public BookingController(BookingService bookingService, CurrentUser currentUser) {
        this.bookingService = bookingService;
        this.currentUser = currentUser;
    }

    @PostMapping
    public ResponseEntity<BookingDto> create(@Valid @RequestBody BookingRequest body, HttpServletRequest request) {
        BookingDto dto = bookingService.create(currentUser.require(request), body);
        return ResponseEntity.status(HttpStatus.CREATED).body(dto);
    }

    @GetMapping
    public List<BookingDto> mine(HttpServletRequest request) {
        return bookingService.myBookings(currentUser.require(request));
    }

    @GetMapping("/{id}")
    public BookingDto get(@PathVariable Long id, HttpServletRequest request) {
        return bookingService.get(currentUser.require(request), id);
    }

    @PutMapping("/{id}/cancel")
    public BookingDto cancel(@PathVariable Long id, HttpServletRequest request) {
        return bookingService.cancel(currentUser.require(request), id);
    }
}
