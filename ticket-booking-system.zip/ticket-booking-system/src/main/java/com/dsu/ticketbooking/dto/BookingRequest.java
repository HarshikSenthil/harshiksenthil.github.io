package com.dsu.ticketbooking.dto;

import jakarta.validation.constraints.*;

import java.time.LocalDate;
import java.util.List;

public record BookingRequest(
        @NotNull(message = "is required") Long trainClassId,
        @NotNull(message = "is required") @FutureOrPresent(message = "cannot be in the past") LocalDate travelDate,
        @NotEmpty(message = "select at least one seat") List<@NotNull @Positive Integer> seatNumbers,
        @NotBlank(message = "is required") @Size(max = 100) String passengerName) {
}
