package com.dsu.ticketbooking.service;

import com.dsu.ticketbooking.dto.ReportDto;
import com.dsu.ticketbooking.model.BookingStatus;
import com.dsu.ticketbooking.model.PaymentStatus;
import com.dsu.ticketbooking.repository.BookingRepository;
import com.dsu.ticketbooking.repository.PaymentRepository;
import com.dsu.ticketbooking.repository.TrainRepository;
import com.dsu.ticketbooking.repository.UserRepository;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Figures for the admin dashboard. */
@Service
public class ReportService {

    private final BookingRepository bookingRepository;
    private final PaymentRepository paymentRepository;
    private final TrainRepository trainRepository;
    private final UserRepository userRepository;

    public ReportService(BookingRepository bookingRepository, PaymentRepository paymentRepository,
                         TrainRepository trainRepository, UserRepository userRepository) {
        this.bookingRepository = bookingRepository;
        this.paymentRepository = paymentRepository;
        this.trainRepository = trainRepository;
        this.userRepository = userRepository;
    }

    @Transactional(readOnly = true)
    public ReportDto summary() {
        List<Map<String, Object>> topTrains = new ArrayList<>();
        for (Object[] row : bookingRepository.topTrains(BookingStatus.CONFIRMED, PageRequest.of(0, 5))) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("trainNumber", row[0]);
            m.put("trainName", row[1]);
            m.put("bookings", row[2]);
            topTrains.add(m);
        }
        List<Map<String, Object>> byClass = new ArrayList<>();
        for (Object[] row : bookingRepository.bookingsByClass(BookingStatus.CONFIRMED)) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("classCode", row[0]);
            m.put("bookings", row[1]);
            byClass.add(m);
        }
        return new ReportDto(
                bookingRepository.count(),
                bookingRepository.countByStatus(BookingStatus.CONFIRMED),
                bookingRepository.countByStatus(BookingStatus.CANCELLED),
                bookingRepository.countByStatus(BookingStatus.FAILED) + bookingRepository.countByStatus(BookingStatus.EXPIRED),
                bookingRepository.countByStatus(BookingStatus.PENDING),
                paymentRepository.sumByStatus(PaymentStatus.SUCCESS),
                paymentRepository.sumByStatus(PaymentStatus.REFUNDED),
                trainRepository.count(),
                userRepository.count(),
                topTrains, byClass);
    }
}
