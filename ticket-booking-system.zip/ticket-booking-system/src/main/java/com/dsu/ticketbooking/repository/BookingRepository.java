package com.dsu.ticketbooking.repository;

import com.dsu.ticketbooking.model.Booking;
import com.dsu.ticketbooking.model.BookingStatus;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;

public interface BookingRepository extends JpaRepository<Booking, Long> {

    List<Booking> findByUserIdOrderByCreatedAtDesc(Long userId);

    List<Booking> findAllByOrderByCreatedAtDesc(Pageable pageable);

    boolean existsByPnr(String pnr);

    long countByStatus(BookingStatus status);

    boolean existsByTrainClassTrainId(Long trainId);

    boolean existsByTrainClassId(Long trainClassId);

    List<Booking> findByStatusAndHoldExpiresAtBefore(BookingStatus status, LocalDateTime time);

    /** Most booked trains: [trainNumber, trainName, bookings]. */
    @Query("""
            select b.trainClass.train.trainNumber, b.trainClass.train.trainName, count(b)
            from Booking b where b.status = :status
            group by b.trainClass.train.trainNumber, b.trainClass.train.trainName
            order by count(b) desc
            """)
    List<Object[]> topTrains(@Param("status") BookingStatus status, Pageable pageable);

    /** Bookings per class: [classCode, bookings]. */
    @Query("""
            select b.trainClass.classCode, count(b) from Booking b where b.status = :status
            group by b.trainClass.classCode order by count(b) desc
            """)
    List<Object[]> bookingsByClass(@Param("status") BookingStatus status);
}
