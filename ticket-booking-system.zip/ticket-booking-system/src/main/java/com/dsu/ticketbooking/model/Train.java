package com.dsu.ticketbooking.model;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

/** A train service (loaded from the Kaggle dataset or added by the admin). */
@Entity
@Table(name = "trains")
public class Train {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "train_number", nullable = false, unique = true, length = 10)
    private String trainNumber;

    @Column(name = "train_name", nullable = false, length = 120)
    private String trainName;

    @Column(name = "source_code", nullable = false, length = 10)
    private String sourceCode;

    @Column(name = "source_name", length = 100)
    private String sourceName;

    @Column(name = "destination_code", nullable = false, length = 10)
    private String destinationCode;

    @Column(name = "destination_name", length = 100)
    private String destinationName;

    /** "HH:mm" */
    @Column(name = "departure_time", length = 5)
    private String departureTime;

    /** "HH:mm" */
    @Column(name = "arrival_time", length = 5)
    private String arrivalTime;

    /** e.g. "6h 55m" */
    @Column(length = 20)
    private String duration;

    @OneToMany(mappedBy = "train", cascade = CascadeType.ALL, orphanRemoval = true)
    @OrderBy("fare ASC")
    private List<TrainClass> classes = new ArrayList<>();

    public void addClass(TrainClass trainClass) {
        trainClass.setTrain(this);
        classes.add(trainClass);
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getTrainNumber() { return trainNumber; }
    public void setTrainNumber(String trainNumber) { this.trainNumber = trainNumber; }
    public String getTrainName() { return trainName; }
    public void setTrainName(String trainName) { this.trainName = trainName; }
    public String getSourceCode() { return sourceCode; }
    public void setSourceCode(String sourceCode) { this.sourceCode = sourceCode; }
    public String getSourceName() { return sourceName; }
    public void setSourceName(String sourceName) { this.sourceName = sourceName; }
    public String getDestinationCode() { return destinationCode; }
    public void setDestinationCode(String destinationCode) { this.destinationCode = destinationCode; }
    public String getDestinationName() { return destinationName; }
    public void setDestinationName(String destinationName) { this.destinationName = destinationName; }
    public String getDepartureTime() { return departureTime; }
    public void setDepartureTime(String departureTime) { this.departureTime = departureTime; }
    public String getArrivalTime() { return arrivalTime; }
    public void setArrivalTime(String arrivalTime) { this.arrivalTime = arrivalTime; }
    public String getDuration() { return duration; }
    public void setDuration(String duration) { this.duration = duration; }
    public List<TrainClass> getClasses() { return classes; }
    public void setClasses(List<TrainClass> classes) { this.classes = classes; }
}
