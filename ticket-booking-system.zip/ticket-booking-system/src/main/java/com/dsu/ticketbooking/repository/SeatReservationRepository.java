package com.dsu.ticketbooking.repository;

import com.dsu.ticketbooking.model.SeatReservation;
import com.dsu.ticketbooking.model.SeatStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface SeatReservationRepository extends JpaRepository<SeatReservation, Long> {

    Optional<SeatReservation> findByTrainClassIdAndTravelDateAndSeatNo(Long trainClassId, LocalDate travelDate, int seatNo);

    List<SeatReservation> findByBookingId(Long bookingId);

    /** Seats that are booked, or locked by someone who is still paying. */
    @Query("""
            select r.seatNo from SeatReservation r
            where r.trainClass.id = :classId and r.travelDate = :date
              and (r.status = :booked or r.lockedUntil > :now)
            order by r.seatNo
            """)
    List<Integer> findUnavailableSeatNos(@Param("classId") Long classId, @Param("date") LocalDate date,
                                         @Param("now") LocalDateTime now, @Param("booked") SeatStatus booked);

    @Query("""
            select count(r) from SeatReservation r
            where r.trainClass.id = :classId and r.travelDate = :date
              and (r.status = :booked or r.lockedUntil > :now)
            """)
    long countUnavailable(@Param("classId") Long classId, @Param("date") LocalDate date,
                          @Param("now") LocalDateTime now, @Param("booked") SeatStatus booked);
}
