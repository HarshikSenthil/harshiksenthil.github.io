package com.dsu.ticketbooking.service;

import com.dsu.ticketbooking.exception.ApiException;
import com.dsu.ticketbooking.model.Booking;
import com.dsu.ticketbooking.model.SeatReservation;
import com.dsu.ticketbooking.model.SeatStatus;
import com.dsu.ticketbooking.model.TrainClass;
import com.dsu.ticketbooking.repository.SeatReservationRepository;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Seat locking - the heart of double-booking prevention.
 *  1. On "Proceed to pay" the chosen seats are saved as LOCKED until a deadline.
 *  2. On successful payment they become BOOKED.
 *  3. On failed payment, cancellation or timeout the rows are deleted, so the seats are free again.
 * Two layers of protection: a check in code, plus a UNIQUE (class, date, seat) constraint in the database.
 */
@Service
public class SeatService {

    private final SeatReservationRepository seatRepository;

    public SeatService(SeatReservationRepository seatRepository) {
        this.seatRepository = seatRepository;
    }

    @Transactional(readOnly = true)
    public List<Integer> unavailableSeats(Long classId, LocalDate date) {
        return seatRepository.findUnavailableSeatNos(classId, date, LocalDateTime.now(), SeatStatus.BOOKED);
    }

    @Transactional(readOnly = true)
    public int availableCount(TrainClass trainClass, LocalDate date) {
        long taken = seatRepository.countUnavailable(trainClass.getId(), date, LocalDateTime.now(), SeatStatus.BOOKED);
        return (int) Math.max(0, trainClass.getTotalSeats() - taken);
    }

    @Transactional
    public void lockSeats(TrainClass trainClass, LocalDate date, List<Integer> seatNumbers,
                          Booking booking, LocalDateTime lockedUntil) {
        LocalDateTime now = LocalDateTime.now();
        for (Integer seatNo : seatNumbers) {
            if (seatNo == null || seatNo < 1 || seatNo > trainClass.getTotalSeats()) {
                throw ApiException.badRequest("Seat " + seatNo + " does not exist in this class");
            }
            seatRepository.findByTrainClassIdAndTravelDateAndSeatNo(trainClass.getId(), date, seatNo)
                    .ifPresent(existing -> {
                        boolean stillHeld = existing.getStatus() == SeatStatus.BOOKED
                                || (existing.getLockedUntil() != null && existing.getLockedUntil().isAfter(now));
                        if (stillHeld) {
                            throw ApiException.conflict("Seat " + seatNo + " has just been taken. Please choose another seat.");
                        }
                        // an old lock whose payment window has passed: remove it first
                        seatRepository.delete(existing);
                        seatRepository.flush();
                    });

            SeatReservation reservation = new SeatReservation();
            reservation.setTrainClass(trainClass);
            reservation.setTravelDate(date);
            reservation.setSeatNo(seatNo);
            reservation.setStatus(SeatStatus.LOCKED);
            reservation.setLockedUntil(lockedUntil);
            reservation.setBooking(booking);
            try {
                seatRepository.saveAndFlush(reservation);
            } catch (DataIntegrityViolationException e) {
                // another customer saved the same seat a moment earlier: the database constraint stopped it
                throw ApiException.conflict("Seat " + seatNo + " has just been taken. Please choose another seat.");
            }
        }
    }

    @Transactional
    public void confirmSeats(Booking booking) {
        List<SeatReservation> seats = seatRepository.findByBookingId(booking.getId());
        for (SeatReservation seat : seats) {
            seat.setStatus(SeatStatus.BOOKED);
            seat.setLockedUntil(null);
        }
        seatRepository.saveAll(seats);
    }

    @Transactional
    public void releaseSeats(Booking booking) {
        List<SeatReservation> seats = seatRepository.findByBookingId(booking.getId());
        seatRepository.deleteAll(seats);
        seatRepository.flush();
    }
}
