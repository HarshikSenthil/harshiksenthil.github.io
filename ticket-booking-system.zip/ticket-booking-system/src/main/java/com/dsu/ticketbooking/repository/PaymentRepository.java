package com.dsu.ticketbooking.repository;

import com.dsu.ticketbooking.model.Payment;
import com.dsu.ticketbooking.model.PaymentStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

public interface PaymentRepository extends JpaRepository<Payment, Long> {

    List<Payment> findByBookingId(Long bookingId);

    Optional<Payment> findFirstByBookingIdAndProviderOrderId(Long bookingId, String providerOrderId);

    @Query("select coalesce(sum(p.amount), 0) from Payment p where p.status = :status")
    BigDecimal sumByStatus(@Param("status") PaymentStatus status);
}
