package com.dsu.ticketbooking.service;

import com.dsu.ticketbooking.dto.BookingDto;
import com.dsu.ticketbooking.exception.ApiException;
import com.dsu.ticketbooking.model.*;
import com.dsu.ticketbooking.repository.PaymentRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestClient;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.LocalDateTime;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Payment module.
 *  MOCK mode     - built-in simulated gateway (success / declined card), works offline.
 *  RAZORPAY mode - Razorpay Test Mode: the server creates an order, the browser opens Razorpay Checkout,
 *                  and the server verifies the HMAC-SHA256 signature before confirming the booking.
 * Methods use noRollbackFor so that a FAILED payment is still saved when an error is returned.
 */
@Service
public class PaymentService {

    private static final Logger log = LoggerFactory.getLogger(PaymentService.class);

    private final PaymentRepository paymentRepository;
    private final BookingService bookingService;
    private final String mode;
    private final String keyId;
    private final String keySecret;

    public PaymentService(PaymentRepository paymentRepository, BookingService bookingService,
                          @Value("${app.payment.mode:MOCK}") String mode,
                          @Value("${app.razorpay.key-id:}") String keyId,
                          @Value("${app.razorpay.key-secret:}") String keySecret) {
        this.paymentRepository = paymentRepository;
        this.bookingService = bookingService;
        this.keyId = keyId == null ? "" : keyId.trim();
        this.keySecret = keySecret == null ? "" : keySecret.trim();
        boolean razorpayReady = "RAZORPAY".equalsIgnoreCase(mode) && !this.keyId.isEmpty() && !this.keySecret.isEmpty();
        if ("RAZORPAY".equalsIgnoreCase(mode) && !razorpayReady) {
            log.warn("app.payment.mode=RAZORPAY but keys are missing - falling back to MOCK payments");
        }
        this.mode = razorpayReady ? "RAZORPAY" : "MOCK";
    }

    public Map<String, Object> config() {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("mode", mode);
        map.put("keyId", "RAZORPAY".equals(mode) ? keyId : null);
        return map;
    }

    // ------------------------------------------------------------ MOCK gateway

    @Transactional(noRollbackFor = ApiException.class)
    public BookingDto payMock(User user, Long bookingId, boolean success) {
        Booking booking = loadPayable(user, bookingId);
        Payment payment = newPayment(booking, "MOCK");
        payment.setProviderOrderId("MOCKORD-" + booking.getPnr());
        payment.setProviderPaymentId("MOCKPAY-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        if (success) {
            payment.setStatus(PaymentStatus.SUCCESS);
            paymentRepository.save(payment);
            bookingService.confirm(booking);
        } else {
            payment.setStatus(PaymentStatus.FAILED);
            paymentRepository.save(payment);
            bookingService.close(booking, BookingStatus.FAILED);
        }
        return bookingService.toDto(booking);
    }

    // ------------------------------------------------------------ RAZORPAY test mode

    @Transactional(noRollbackFor = ApiException.class)
    public Map<String, Object> createRazorpayOrder(User user, Long bookingId) {
        requireRazorpay();
        Booking booking = loadPayable(user, bookingId);
        long amountInPaise = booking.getTotalAmount().movePointRight(2).longValueExact();

        Map<String, Object> request = new LinkedHashMap<>();
        request.put("amount", amountInPaise);
        request.put("currency", "INR");
        request.put("receipt", booking.getPnr());

        Map<?, ?> response;
        try {
            response = RestClient.create("https://api.razorpay.com")
                    .post().uri("/v1/orders")
                    .headers(h -> h.setBasicAuth(keyId, keySecret))
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(request)
                    .retrieve()
                    .body(Map.class);
        } catch (Exception e) {
            log.error("Razorpay order creation failed: {}", e.getMessage());
            throw new ApiException(HttpStatus.BAD_GATEWAY, "Could not reach the payment gateway. Please try again.");
        }
        if (response == null || response.get("id") == null) {
            throw new ApiException(HttpStatus.BAD_GATEWAY, "Invalid response from the payment gateway");
        }
        String orderId = String.valueOf(response.get("id"));

        Payment payment = newPayment(booking, "RAZORPAY");
        payment.setStatus(PaymentStatus.CREATED);
        payment.setProviderOrderId(orderId);
        paymentRepository.save(payment);

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("keyId", keyId);
        result.put("orderId", orderId);
        result.put("amount", amountInPaise);
        result.put("currency", "INR");
        result.put("pnr", booking.getPnr());
        result.put("customerName", user.getName());
        result.put("customerEmail", user.getEmail());
        return result;
    }

    @Transactional(noRollbackFor = ApiException.class)
    public BookingDto verifyRazorpay(User user, Long bookingId, String orderId, String paymentId, String signature) {
        requireRazorpay();
        Booking booking = loadPayable(user, bookingId);
        Payment payment = paymentRepository.findFirstByBookingIdAndProviderOrderId(bookingId, orderId)
                .orElseThrow(() -> ApiException.badRequest("Unknown payment order"));
        payment.setProviderPaymentId(paymentId);

        if (!signatureMatches(orderId + "|" + paymentId, signature)) {
            payment.setStatus(PaymentStatus.FAILED);
            paymentRepository.save(payment);
            bookingService.close(booking, BookingStatus.FAILED);
            throw ApiException.badRequest("Payment verification failed. No money was taken in test mode.");
        }
        payment.setStatus(PaymentStatus.SUCCESS);
        paymentRepository.save(payment);
        bookingService.confirm(booking);
        return bookingService.toDto(booking);
    }

    // ------------------------------------------------------------ helpers

    /** The booking must belong to the user, be PENDING and still inside its seat-hold window. */
    private Booking loadPayable(User user, Long bookingId) {
        Booking booking = bookingService.findOwned(user, bookingId);
        if (booking.getStatus() != BookingStatus.PENDING) {
            throw ApiException.conflict("This booking is not awaiting payment (status: " + booking.getStatus() + ")");
        }
        if (booking.getHoldExpiresAt() == null || booking.getHoldExpiresAt().isBefore(LocalDateTime.now())) {
            bookingService.close(booking, BookingStatus.EXPIRED);
            throw ApiException.conflict("The seat hold has expired. Please book again.");
        }
        return booking;
    }

    private Payment newPayment(Booking booking, String provider) {
        Payment payment = new Payment();
        payment.setBooking(booking);
        payment.setAmount(booking.getTotalAmount() == null ? BigDecimal.ZERO : booking.getTotalAmount());
        payment.setProvider(provider);
        return payment;
    }

    private void requireRazorpay() {
        if (!"RAZORPAY".equals(mode)) {
            throw ApiException.badRequest("Razorpay is not enabled. Set app.payment.mode=RAZORPAY and the test keys.");
        }
    }

    private boolean signatureMatches(String payload, String signature) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(keySecret.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
            String expected = HexFormat.of().formatHex(mac.doFinal(payload.getBytes(StandardCharsets.UTF_8)));
            return MessageDigest.isEqual(expected.getBytes(StandardCharsets.UTF_8),
                    signature.getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) {
            return false;
        }
    }
}
