package com.dsu.ticketbooking.controller;

import com.dsu.ticketbooking.dto.SeatMap;
import com.dsu.ticketbooking.dto.StationDto;
import com.dsu.ticketbooking.dto.TrainResult;
import com.dsu.ticketbooking.service.TrainService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

/** Public endpoints: no login needed to search. */
@RestController
@RequestMapping("/api")
public class TrainController {

    private final TrainService trainService;

    public TrainController(TrainService trainService) {
        this.trainService = trainService;
    }

    @GetMapping("/stations")
    public List<StationDto> stations() {
        return trainService.stations();
    }

    @GetMapping("/trains/search")
    public List<TrainResult> search(@RequestParam String from, @RequestParam String to,
                                    @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        return trainService.search(from, to, date);
    }

    @GetMapping("/trains/classes/{classId}/seats")
    public SeatMap seats(@PathVariable Long classId,
                         @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        return trainService.seatMap(classId, date);
    }
}
