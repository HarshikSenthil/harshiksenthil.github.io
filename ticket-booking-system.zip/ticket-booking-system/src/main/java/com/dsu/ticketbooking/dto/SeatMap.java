package com.dsu.ticketbooking.dto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

public record SeatMap(Long classId, String trainNumber, String trainName, String classCode,
                      String sourceName, String destinationName, String departureTime, String arrivalTime,
                      BigDecimal fare, BigDecimal serviceFeePercent, int maxSeats,
                      LocalDate travelDate, int totalSeats, List<Integer> unavailable) {
}
