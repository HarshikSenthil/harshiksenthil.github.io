package com.dsu.ticketbooking.dto;

import java.util.List;

public record TrainResult(Long trainId, String trainNumber, String trainName,
                          String sourceCode, String sourceName, String destinationCode, String destinationName,
                          String departureTime, String arrivalTime, String duration,
                          List<ClassInfo> classes) {
}
