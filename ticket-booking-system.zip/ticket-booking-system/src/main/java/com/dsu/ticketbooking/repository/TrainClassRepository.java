package com.dsu.ticketbooking.repository;

import com.dsu.ticketbooking.model.TrainClass;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TrainClassRepository extends JpaRepository<TrainClass, Long> {
}
