package com.dsu.ticketbooking.service;

import com.dsu.ticketbooking.dto.*;
import com.dsu.ticketbooking.exception.ApiException;
import com.dsu.ticketbooking.model.Train;
import com.dsu.ticketbooking.model.TrainClass;
import com.dsu.ticketbooking.repository.BookingRepository;
import com.dsu.ticketbooking.repository.TrainClassRepository;
import com.dsu.ticketbooking.repository.TrainRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.*;

/** Searching trains, seat maps and (for the admin) managing trains, classes and fares. */
@Service
public class TrainService {

    private final TrainRepository trainRepository;
    private final TrainClassRepository classRepository;
    private final BookingRepository bookingRepository;
    private final SeatService seatService;
    private final FareCalculator fareCalculator;
    private final int maxSeats;

    public TrainService(TrainRepository trainRepository, TrainClassRepository classRepository,
                        BookingRepository bookingRepository, SeatService seatService,
                        FareCalculator fareCalculator, @Value("${app.booking.max-seats:6}") int maxSeats) {
        this.trainRepository = trainRepository;
        this.classRepository = classRepository;
        this.bookingRepository = bookingRepository;
        this.seatService = seatService;
        this.fareCalculator = fareCalculator;
        this.maxSeats = maxSeats;
    }

    // ------------------------------------------------------------ customer side

    @Transactional(readOnly = true)
    public List<StationDto> stations() {
        Map<String, String> map = new TreeMap<>();
        List<Object[]> rows = new ArrayList<>(trainRepository.findSourceStations());
        rows.addAll(trainRepository.findDestinationStations());
        for (Object[] row : rows) {
            String code = (String) row[0];
            String name = row[1] == null ? code : (String) row[1];
            map.putIfAbsent(code, name);
        }
        List<StationDto> list = new ArrayList<>();
        map.forEach((code, name) -> list.add(new StationDto(code, name)));
        list.sort(Comparator.comparing(StationDto::name, String.CASE_INSENSITIVE_ORDER));
        return list;
    }

    @Transactional(readOnly = true)
    public List<TrainResult> search(String from, String to, LocalDate date) {
        if (from == null || from.isBlank() || to == null || to.isBlank()) {
            throw ApiException.badRequest("Please enter both the From and To stations");
        }
        if (date == null) {
            date = LocalDate.now();
        }
        if (date.isBefore(LocalDate.now())) {
            throw ApiException.badRequest("Travel date cannot be in the past");
        }
        List<TrainResult> results = new ArrayList<>();
        for (Train train : trainRepository.search(from.trim(), to.trim())) {
            List<ClassInfo> classes = new ArrayList<>();
            for (TrainClass c : train.getClasses()) {
                classes.add(new ClassInfo(c.getId(), c.getClassCode(), c.getFare(), c.getTotalSeats(),
                        seatService.availableCount(c, date)));
            }
            results.add(toResult(train, classes));
        }
        return results;
    }

    @Transactional(readOnly = true)
    public SeatMap seatMap(Long classId, LocalDate date) {
        if (date == null || date.isBefore(LocalDate.now())) {
            throw ApiException.badRequest("Please choose a valid travel date");
        }
        TrainClass c = classRepository.findById(classId)
                .orElseThrow(() -> ApiException.notFound("Train class not found"));
        Train t = c.getTrain();
        return new SeatMap(c.getId(), t.getTrainNumber(), t.getTrainName(), c.getClassCode(),
                display(t.getSourceName(), t.getSourceCode()), display(t.getDestinationName(), t.getDestinationCode()),
                t.getDepartureTime(), t.getArrivalTime(), c.getFare(), fareCalculator.getServiceFeePercent(), maxSeats,
                date, c.getTotalSeats(), seatService.unavailableSeats(classId, date));
    }

    // ------------------------------------------------------------ admin side

    @Transactional(readOnly = true)
    public List<TrainResult> adminList(String q) {
        PageRequest page = PageRequest.of(0, 200);
        List<Train> trains = (q == null || q.isBlank())
                ? trainRepository.findAllOrdered(page)
                : trainRepository.adminSearch(q.trim(), page);
        return trains.stream().map(this::toAdminResult).toList();
    }

    @Transactional
    public TrainResult createTrain(TrainForm form) {
        String number = form.trainNumber().trim();
        if (trainRepository.existsByTrainNumber(number)) {
            throw ApiException.conflict("Train " + number + " already exists");
        }
        Train train = new Train();
        train.setTrainNumber(number);
        applyForm(train, form);
        Set<String> codes = new HashSet<>();
        if (form.classes() != null) {
            for (ClassForm cf : form.classes()) {
                String code = cf.classCode().trim().toUpperCase(Locale.ROOT);
                if (!codes.add(code)) {
                    throw ApiException.badRequest("Class " + code + " is listed twice");
                }
                train.addClass(newClass(cf));
            }
        }
        return toAdminResult(trainRepository.save(train));
    }

    @Transactional
    public TrainResult updateTrain(Long id, TrainForm form) {
        Train train = trainRepository.findById(id).orElseThrow(() -> ApiException.notFound("Train not found"));
        String number = form.trainNumber().trim();
        if (!number.equals(train.getTrainNumber()) && trainRepository.existsByTrainNumber(number)) {
            throw ApiException.conflict("Train " + number + " already exists");
        }
        train.setTrainNumber(number);
        applyForm(train, form);
        return toAdminResult(train);
    }

    @Transactional
    public void deleteTrain(Long id) {
        Train train = trainRepository.findById(id).orElseThrow(() -> ApiException.notFound("Train not found"));
        if (bookingRepository.existsByTrainClassTrainId(id)) {
            throw ApiException.conflict("This train has bookings and cannot be deleted");
        }
        trainRepository.delete(train);
    }

    @Transactional
    public TrainResult addClass(Long trainId, ClassForm form) {
        Train train = trainRepository.findById(trainId).orElseThrow(() -> ApiException.notFound("Train not found"));
        String code = form.classCode().trim().toUpperCase(Locale.ROOT);
        boolean exists = train.getClasses().stream().anyMatch(c -> c.getClassCode().equalsIgnoreCase(code));
        if (exists) {
            throw ApiException.conflict("Class " + code + " already exists for this train");
        }
        train.addClass(newClass(form));
        trainRepository.saveAndFlush(train);
        return toAdminResult(train);
    }

    @Transactional
    public ClassInfo updateClass(Long classId, ClassForm form) {
        TrainClass c = classRepository.findById(classId).orElseThrow(() -> ApiException.notFound("Class not found"));
        c.setFare(form.fare());
        c.setTotalSeats(form.totalSeats());
        return new ClassInfo(c.getId(), c.getClassCode(), c.getFare(), c.getTotalSeats(), null);
    }

    @Transactional
    public void deleteClass(Long classId) {
        TrainClass c = classRepository.findById(classId).orElseThrow(() -> ApiException.notFound("Class not found"));
        if (bookingRepository.existsByTrainClassId(classId)) {
            throw ApiException.conflict("This class has bookings and cannot be deleted");
        }
        c.getTrain().getClasses().remove(c);
    }

    // ------------------------------------------------------------ helpers

    private void applyForm(Train train, TrainForm form) {
        train.setTrainName(form.trainName().trim());
        train.setSourceCode(form.sourceCode().trim().toUpperCase(Locale.ROOT));
        train.setSourceName(blankToNull(form.sourceName()));
        train.setDestinationCode(form.destinationCode().trim().toUpperCase(Locale.ROOT));
        train.setDestinationName(blankToNull(form.destinationName()));
        train.setDepartureTime(blankToNull(form.departureTime()));
        train.setArrivalTime(blankToNull(form.arrivalTime()));
        train.setDuration(blankToNull(form.duration()));
    }

    private TrainClass newClass(ClassForm form) {
        TrainClass c = new TrainClass();
        c.setClassCode(form.classCode().trim().toUpperCase(Locale.ROOT));
        c.setFare(form.fare());
        c.setTotalSeats(form.totalSeats());
        return c;
    }

    private TrainResult toAdminResult(Train t) {
        List<ClassInfo> classes = t.getClasses().stream()
                .map(c -> new ClassInfo(c.getId(), c.getClassCode(), c.getFare(), c.getTotalSeats(), null))
                .toList();
        return toResult(t, classes);
    }

    private TrainResult toResult(Train t, List<ClassInfo> classes) {
        return new TrainResult(t.getId(), t.getTrainNumber(), t.getTrainName(),
                t.getSourceCode(), display(t.getSourceName(), t.getSourceCode()),
                t.getDestinationCode(), display(t.getDestinationName(), t.getDestinationCode()),
                t.getDepartureTime(), t.getArrivalTime(), t.getDuration(), classes);
    }

    private static String display(String name, String code) {
        return (name == null || name.isBlank()) ? code : name;
    }

    private static String blankToNull(String s) {
        return (s == null || s.isBlank()) ? null : s.trim();
    }
}
