package com.dsu.ticketbooking.model;

public enum Role {
    CUSTOMER, ADMIN
}
