package com.dsu.ticketbooking.dto;

import com.dsu.ticketbooking.model.User;

public record UserDto(Long id, String name, String email, String role) {
    public static UserDto from(User u) {
        return new UserDto(u.getId(), u.getName(), u.getEmail(), u.getRole().name());
    }
}
