package com.dsu.ticketbooking.config;

import com.dsu.ticketbooking.exception.ApiException;
import com.dsu.ticketbooking.model.Role;
import com.dsu.ticketbooking.model.User;
import com.dsu.ticketbooking.repository.UserRepository;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Component;

/**
 * Session-based login: after a successful login the user id is stored in the HTTP session.
 * Controllers call require(...) or requireAdmin(...) to protect an endpoint (role-based access).
 */
@Component
public class CurrentUser {

    public static final String SESSION_KEY = "uid";

    private final UserRepository userRepository;

    public CurrentUser(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public User optional(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session == null) {
            return null;
        }
        Object id = session.getAttribute(SESSION_KEY);
        if (!(id instanceof Long userId)) {
            return null;
        }
        return userRepository.findById(userId).orElse(null);
    }

    public User require(HttpServletRequest request) {
        User user = optional(request);
        if (user == null) {
            throw ApiException.unauthorized("Please log in to continue");
        }
        return user;
    }

    public User requireAdmin(HttpServletRequest request) {
        User user = require(request);
        if (user.getRole() != Role.ADMIN) {
            throw ApiException.forbidden("Admin access only");
        }
        return user;
    }

    public void login(HttpServletRequest request, User user) {
        request.getSession(true);
        request.changeSessionId(); // protects against session fixation
        request.getSession().setAttribute(SESSION_KEY, user.getId());
    }

    public void logout(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate();
        }
    }
}
