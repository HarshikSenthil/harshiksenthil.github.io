package com.dsu.ticketbooking.controller;

import com.dsu.ticketbooking.config.CurrentUser;
import com.dsu.ticketbooking.dto.LoginRequest;
import com.dsu.ticketbooking.dto.RegisterRequest;
import com.dsu.ticketbooking.dto.UserDto;
import com.dsu.ticketbooking.model.User;
import com.dsu.ticketbooking.service.AuthService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService authService;
    private final CurrentUser currentUser;

    public AuthController(AuthService authService, CurrentUser currentUser) {
        this.authService = authService;
        this.currentUser = currentUser;
    }

    @PostMapping("/register")
    public ResponseEntity<UserDto> register(@Valid @RequestBody RegisterRequest body, HttpServletRequest request) {
        User user = authService.register(body);
        currentUser.login(request, user);
        return ResponseEntity.status(HttpStatus.CREATED).body(UserDto.from(user));
    }

    @PostMapping("/login")
    public UserDto login(@Valid @RequestBody LoginRequest body, HttpServletRequest request) {
        User user = authService.login(body.email(), body.password());
        currentUser.login(request, user);
        return UserDto.from(user);
    }

    @PostMapping("/logout")
    public ResponseEntity<Void> logout(HttpServletRequest request) {
        currentUser.logout(request);
        return ResponseEntity.noContent().build();
    }

    /** 200 with the user when logged in, 204 when not logged in. */
    @GetMapping("/me")
    public ResponseEntity<UserDto> me(HttpServletRequest request) {
        User user = currentUser.optional(request);
        return user == null ? ResponseEntity.noContent().build() : ResponseEntity.ok(UserDto.from(user));
    }
}
