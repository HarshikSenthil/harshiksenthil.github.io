package com.dsu.ticketbooking.service;

import com.dsu.ticketbooking.model.*;
import com.dsu.ticketbooking.repository.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.io.ClassPathResource;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.Reader;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

/**
 * Runs once at start-up:
 *  1. loads trains/classes/fares from dataset/trains.csv (the cleaned Kaggle file)
 *     or from the bundled sample if that file is missing;
 *  2. creates the admin and demo accounts;
 *  3. optionally creates synthetic customers and bookings for the reports.
 */
@Component
public class DataLoader implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(DataLoader.class);
    private static final List<String> REQUIRED = List.of("train_number", "train_name", "source_code",
            "destination_code", "class_code", "fare", "total_seats");

    private final TrainRepository trainRepository;
    private final UserRepository userRepository;
    private final BookingRepository bookingRepository;
    private final SeatReservationRepository seatRepository;
    private final PaymentRepository paymentRepository;
    private final PasswordEncoder passwordEncoder;
    private final FareCalculator fareCalculator;
    private final String trainsFile;
    private final boolean seedBookings;

    public DataLoader(TrainRepository trainRepository, UserRepository userRepository,
                      BookingRepository bookingRepository, SeatReservationRepository seatRepository,
                      PaymentRepository paymentRepository, PasswordEncoder passwordEncoder,
                      FareCalculator fareCalculator,
                      @Value("${app.data.trains-file:dataset/trains.csv}") String trainsFile,
                      @Value("${app.seed.sample-bookings:true}") boolean seedBookings) {
        this.trainRepository = trainRepository;
        this.userRepository = userRepository;
        this.bookingRepository = bookingRepository;
        this.seatRepository = seatRepository;
        this.paymentRepository = paymentRepository;
        this.passwordEncoder = passwordEncoder;
        this.fareCalculator = fareCalculator;
        this.trainsFile = trainsFile;
        this.seedBookings = seedBookings;
    }

    @Override
    @Transactional
    public void run(String... args) throws Exception {
        if (trainRepository.count() == 0) {
            loadTrains();
        }
        if (userRepository.count() == 0) {
            createUser("Administrator", "admin@tbs.com", "admin123", Role.ADMIN);
            createUser("Demo Customer", "demo@tbs.com", "demo123", Role.CUSTOMER);
            log.info("Created accounts: admin@tbs.com / admin123 and demo@tbs.com / demo123");
        }
        if (seedBookings && bookingRepository.count() == 0) {
            seedSyntheticBookings();
        }
    }

    // ------------------------------------------------------------ trains from CSV

    private void loadTrains() throws Exception {
        Path path = Path.of(trainsFile);
        Reader reader;
        String source;
        if (Files.exists(path)) {
            reader = Files.newBufferedReader(path, StandardCharsets.UTF_8);
            source = path.toAbsolutePath().toString();
        } else {
            reader = new InputStreamReader(new ClassPathResource("data/sample_trains.csv").getInputStream(),
                    StandardCharsets.UTF_8);
            source = "bundled sample data (dataset/trains.csv not found)";
        }

        Map<String, Train> trains = new LinkedHashMap<>();
        int rows = 0;
        int skipped = 0;
        try (BufferedReader br = new BufferedReader(reader)) {
            String headerLine = br.readLine();
            if (headerLine == null) {
                log.warn("Train file is empty: {}", source);
                return;
            }
            List<String> header = parseCsvLine(stripBom(headerLine)).stream()
                    .map(h -> h.trim().toLowerCase(Locale.ROOT)).toList();
            for (String col : REQUIRED) {
                if (!header.contains(col)) {
                    throw new IllegalStateException("Train file " + source + " is missing column '" + col
                            + "'. Run dataset/prepare_dataset.py to create it.");
                }
            }
            String line;
            while ((line = br.readLine()) != null) {
                if (line.isBlank()) {
                    continue;
                }
                rows++;
                try {
                    List<String> values = parseCsvLine(line);
                    Map<String, String> r = new HashMap<>();
                    for (int i = 0; i < header.size() && i < values.size(); i++) {
                        r.put(header.get(i), values.get(i).trim());
                    }
                    String number = r.get("train_number");
                    String classCode = r.get("class_code").toUpperCase(Locale.ROOT);
                    if (number == null || number.isEmpty() || classCode.isEmpty()) {
                        skipped++;
                        continue;
                    }
                    Train train = trains.computeIfAbsent(number, n -> {
                        Train t = new Train();
                        t.setTrainNumber(n);
                        t.setTrainName(cut(r.get("train_name"), 120));
                        t.setSourceCode(cut(r.get("source_code").toUpperCase(Locale.ROOT), 10));
                        t.setSourceName(cut(r.get("source_name"), 100));
                        t.setDestinationCode(cut(r.get("destination_code").toUpperCase(Locale.ROOT), 10));
                        t.setDestinationName(cut(r.get("destination_name"), 100));
                        t.setDepartureTime(time(r.get("departure_time")));
                        t.setArrivalTime(time(r.get("arrival_time")));
                        t.setDuration(cut(r.get("duration"), 20));
                        return t;
                    });
                    boolean duplicateClass = train.getClasses().stream()
                            .anyMatch(c -> c.getClassCode().equals(classCode));
                    if (duplicateClass) {
                        skipped++;
                        continue;
                    }
                    TrainClass tc = new TrainClass();
                    tc.setClassCode(cut(classCode, 5));
                    tc.setFare(new BigDecimal(r.get("fare")).setScale(2, java.math.RoundingMode.HALF_UP));
                    tc.setTotalSeats(Math.max(1, Math.min(200, Integer.parseInt(r.get("total_seats")))));
                    train.addClass(tc);
                } catch (Exception e) {
                    skipped++;
                }
            }
        }
        trains.values().removeIf(t -> t.getTrainName() == null || t.getSourceCode() == null
                || t.getDestinationCode() == null || t.getClasses().isEmpty());
        trainRepository.saveAll(trains.values());
        log.info("Loaded {} trains from {} ({} rows read, {} skipped)", trains.size(), source, rows, skipped);
    }

    // ------------------------------------------------------------ users and synthetic bookings

    private User createUser(String name, String email, String password, Role role) {
        User u = new User();
        u.setName(name);
        u.setEmail(email);
        u.setPasswordHash(passwordEncoder.encode(password));
        u.setRole(role);
        return userRepository.save(u);
    }

    /** Synthetic customers and bookings (fixed random seed, so every run gives the same data). */
    private void seedSyntheticBookings() {
        List<Train> trains = trainRepository.findAll();
        if (trains.isEmpty()) {
            return;
        }
        String[] names = {"Aarav Sharma", "Diya Patel", "Rohan Iyer", "Ananya Reddy", "Vikram Nair",
                "Sneha Kulkarni", "Karthik Rao", "Priya Menon", "Arjun Gowda", "Meera Joshi"};
        List<User> customers = new ArrayList<>();
        for (String n : names) {
            String email = n.toLowerCase(Locale.ROOT).replace(' ', '.') + "@example.com";
            customers.add(createUser(n, email, "password123", Role.CUSTOMER));
        }

        Random rnd = new Random(42);
        Set<String> usedSeats = new HashSet<>();
        Set<String> usedPnrs = new HashSet<>();
        int created = 0;
        for (int i = 0; i < 60; i++) {
            Train train = trains.get(rnd.nextInt(trains.size()));
            TrainClass tc = train.getClasses().get(rnd.nextInt(train.getClasses().size()));
            LocalDate date = LocalDate.now().plusDays(rnd.nextInt(31) - 15);
            int seatsWanted = 1 + rnd.nextInt(3);
            List<Integer> seats = new ArrayList<>();
            for (int s = 1; s <= tc.getTotalSeats() && seats.size() < seatsWanted; s++) {
                String key = tc.getId() + "|" + date + "|" + s;
                if (!usedSeats.contains(key) && rnd.nextInt(3) == 0) {
                    usedSeats.add(key);
                    seats.add(s);
                }
            }
            if (seats.isEmpty()) {
                continue;
            }
            User customer = customers.get(rnd.nextInt(customers.size()));
            FareCalculator.FareBreakdown fare = fareCalculator.calculate(tc.getFare(), seats.size());
            int roll = rnd.nextInt(100);
            BookingStatus status = roll < 78 ? BookingStatus.CONFIRMED : roll < 90 ? BookingStatus.CANCELLED : BookingStatus.FAILED;

            String pnr;
            do {
                pnr = String.valueOf(1_000_000_000L + (long) (rnd.nextDouble() * 8_999_999_999L));
            } while (!usedPnrs.add(pnr));

            Booking b = new Booking();
            b.setPnr(pnr);
            b.setUser(customer);
            b.setTrainClass(tc);
            b.setTravelDate(date);
            b.setPassengerName(customer.getName());
            b.setSeatNumbers(String.join(",", seats.stream().map(String::valueOf).toList()));
            b.setSubtotal(fare.subtotal());
            b.setServiceFee(fare.serviceFee());
            b.setTotalAmount(fare.total());
            b.setStatus(status);
            b.setCreatedAt(LocalDateTime.now().minusDays(rnd.nextInt(20) + 1L).minusMinutes(rnd.nextInt(600)));
            bookingRepository.save(b);

            if (status == BookingStatus.CONFIRMED) {
                for (Integer s : seats) {
                    SeatReservation r = new SeatReservation();
                    r.setTrainClass(tc);
                    r.setTravelDate(date);
                    r.setSeatNo(s);
                    r.setStatus(SeatStatus.BOOKED);
                    r.setBooking(b);
                    seatRepository.save(r);
                }
            }
            Payment p = new Payment();
            p.setBooking(b);
            p.setAmount(fare.total());
            p.setProvider("MOCK");
            p.setProviderOrderId("MOCKORD-" + pnr);
            p.setProviderPaymentId("MOCKPAY-SEED" + i);
            p.setCreatedAt(b.getCreatedAt());
            p.setStatus(status == BookingStatus.CONFIRMED ? PaymentStatus.SUCCESS
                    : status == BookingStatus.CANCELLED ? PaymentStatus.REFUNDED : PaymentStatus.FAILED);
            paymentRepository.save(p);
            created++;
        }
        log.info("Created {} synthetic customers and {} synthetic bookings", customers.size(), created);
    }

    // ------------------------------------------------------------ CSV helpers

    /** Splits one CSV line, supporting quoted values that contain commas. */
    static List<String> parseCsvLine(String line) {
        List<String> out = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        boolean quoted = false;
        for (int i = 0; i < line.length(); i++) {
            char ch = line.charAt(i);
            if (quoted) {
                if (ch == '"' && i + 1 < line.length() && line.charAt(i + 1) == '"') {
                    cur.append('"');
                    i++;
                } else if (ch == '"') {
                    quoted = false;
                } else {
                    cur.append(ch);
                }
            } else if (ch == '"') {
                quoted = true;
            } else if (ch == ',') {
                out.add(cur.toString());
                cur.setLength(0);
            } else {
                cur.append(ch);
            }
        }
        out.add(cur.toString());
        return out;
    }

    private static String stripBom(String s) {
        return s.startsWith("\uFEFF") ? s.substring(1) : s;
    }

    private static String cut(String s, int max) {
        if (s == null || s.isBlank()) {
            return null;
        }
        String t = s.trim();
        return t.length() > max ? t.substring(0, max) : t;
    }

    /** Accepts "6:05", "06:05" or "06:05:00" and returns "06:05". */
    private static String time(String s) {
        if (s == null || s.isBlank()) {
            return null;
        }
        String[] parts = s.trim().split(":");
        try {
            int h = Integer.parseInt(parts[0].trim());
            int m = parts.length > 1 ? Integer.parseInt(parts[1].trim()) : 0;
            if (h < 0 || h > 23 || m < 0 || m > 59) {
                return null;
            }
            return String.format("%02d:%02d", h, m);
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
