package com.dsu.ticketbooking.service;

import com.dsu.ticketbooking.dto.BookingDto;
import com.dsu.ticketbooking.dto.BookingRequest;
import com.dsu.ticketbooking.exception.ApiException;
import com.dsu.ticketbooking.model.*;
import com.dsu.ticketbooking.repository.BookingRepository;
import com.dsu.ticketbooking.repository.PaymentRepository;
import com.dsu.ticketbooking.repository.TrainClassRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.SecureRandom;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/** Creating, viewing, confirming and cancelling bookings. */
@Service
public class BookingService {

    private static final Logger log = LoggerFactory.getLogger(BookingService.class);
    private final SecureRandom random = new SecureRandom();

    private final BookingRepository bookingRepository;
    private final TrainClassRepository classRepository;
    private final PaymentRepository paymentRepository;
    private final SeatService seatService;
    private final FareCalculator fareCalculator;
    private final NotificationService notificationService;
    private final int holdMinutes;
    private final int maxSeats;

    public BookingService(BookingRepository bookingRepository, TrainClassRepository classRepository,
                          PaymentRepository paymentRepository, SeatService seatService,
                          FareCalculator fareCalculator, NotificationService notificationService,
                          @Value("${app.booking.hold-minutes:10}") int holdMinutes,
                          @Value("${app.booking.max-seats:6}") int maxSeats) {
        this.bookingRepository = bookingRepository;
        this.classRepository = classRepository;
        this.paymentRepository = paymentRepository;
        this.seatService = seatService;
        this.fareCalculator = fareCalculator;
        this.notificationService = notificationService;
        this.holdMinutes = holdMinutes;
        this.maxSeats = maxSeats;
    }

    /** Step 1 of booking: validate, calculate fare, create a PENDING booking and lock the seats. */
    @Transactional
    public BookingDto create(User user, BookingRequest request) {
        if (request.travelDate().isBefore(LocalDate.now())) {
            throw ApiException.badRequest("Travel date cannot be in the past");
        }
        List<Integer> seats = request.seatNumbers();
        if (seats.size() > maxSeats) {
            throw ApiException.badRequest("You can book at most " + maxSeats + " seats at a time");
        }
        Set<Integer> unique = new HashSet<>(seats);
        if (unique.size() != seats.size()) {
            throw ApiException.badRequest("The same seat was selected twice");
        }
        TrainClass trainClass = classRepository.findById(request.trainClassId())
                .orElseThrow(() -> ApiException.notFound("Train class not found"));

        FareCalculator.FareBreakdown fare = fareCalculator.calculate(trainClass.getFare(), seats.size());
        LocalDateTime holdUntil = LocalDateTime.now().plusMinutes(holdMinutes);

        Booking booking = new Booking();
        booking.setPnr(newPnr());
        booking.setUser(user);
        booking.setTrainClass(trainClass);
        booking.setTravelDate(request.travelDate());
        booking.setPassengerName(request.passengerName().trim());
        booking.setSeatNumbers(seats.stream().sorted().map(String::valueOf).collect(Collectors.joining(",")));
        booking.setSubtotal(fare.subtotal());
        booking.setServiceFee(fare.serviceFee());
        booking.setTotalAmount(fare.total());
        booking.setStatus(BookingStatus.PENDING);
        booking.setHoldExpiresAt(holdUntil);
        bookingRepository.save(booking);

        seatService.lockSeats(trainClass, request.travelDate(), seats.stream().sorted().toList(), booking, holdUntil);
        log.info("Booking {} created (PENDING) for {}", booking.getPnr(), user.getEmail());
        return toDto(booking);
    }

    @Transactional(readOnly = true)
    public List<BookingDto> myBookings(User user) {
        return bookingRepository.findByUserIdOrderByCreatedAtDesc(user.getId()).stream().map(this::toDto).toList();
    }

    @Transactional(readOnly = true)
    public List<BookingDto> allBookings() {
        return bookingRepository.findAllByOrderByCreatedAtDesc(PageRequest.of(0, 500)).stream().map(this::toDto).toList();
    }

    @Transactional(readOnly = true)
    public BookingDto get(User user, Long id) {
        return toDto(findOwned(user, id));
    }

    /** Customers can see only their own bookings; admins can see all. */
    @Transactional(readOnly = true, noRollbackFor = ApiException.class)
    public Booking findOwned(User user, Long id) {
        Booking booking = bookingRepository.findById(id).orElseThrow(() -> ApiException.notFound("Booking not found"));
        boolean owner = booking.getUser().getId().equals(user.getId());
        if (!owner && user.getRole() != Role.ADMIN) {
            throw ApiException.notFound("Booking not found");
        }
        return booking;
    }

    /** Called after a successful payment. */
    @Transactional
    public void confirm(Booking booking) {
        booking.setStatus(BookingStatus.CONFIRMED);
        booking.setHoldExpiresAt(null);
        seatService.confirmSeats(booking);
        bookingRepository.save(booking);
        notificationService.bookingConfirmed(booking);
    }

    /** Called after a failed payment or a timeout: the seats become free again. */
    @Transactional
    public void close(Booking booking, BookingStatus status) {
        booking.setStatus(status);
        booking.setHoldExpiresAt(null);
        seatService.releaseSeats(booking);
        for (Payment p : paymentRepository.findByBookingId(booking.getId())) {
            if (p.getStatus() == PaymentStatus.CREATED) {
                p.setStatus(PaymentStatus.FAILED);
            }
        }
        bookingRepository.save(booking);
    }

    @Transactional
    public BookingDto cancel(User user, Long id) {
        Booking booking = findOwned(user, id);
        if (booking.getStatus() != BookingStatus.CONFIRMED) {
            throw ApiException.conflict("Only confirmed bookings can be cancelled");
        }
        if (booking.getTravelDate().isBefore(LocalDate.now())) {
            throw ApiException.conflict("Past journeys cannot be cancelled");
        }
        booking.setStatus(BookingStatus.CANCELLED);
        seatService.releaseSeats(booking);
        for (Payment p : paymentRepository.findByBookingId(booking.getId())) {
            if (p.getStatus() == PaymentStatus.SUCCESS) {
                p.setStatus(PaymentStatus.REFUNDED); // refund is simulated in test mode
            }
        }
        bookingRepository.save(booking);
        notificationService.bookingCancelled(booking);
        return toDto(booking);
    }

    /** Every minute: bookings that were not paid in time are expired and their seats released. */
    @Scheduled(fixedDelayString = "60000", initialDelayString = "60000")
    @Transactional
    public void expireStaleHolds() {
        List<Booking> stale = bookingRepository.findByStatusAndHoldExpiresAtBefore(BookingStatus.PENDING, LocalDateTime.now());
        for (Booking booking : stale) {
            close(booking, BookingStatus.EXPIRED);
            log.info("Booking {} expired, seats released", booking.getPnr());
        }
    }

    public BookingDto toDto(Booking b) {
        Train t = b.getTrainClass().getTrain();
        long secondsLeft = 0;
        if (b.getStatus() == BookingStatus.PENDING && b.getHoldExpiresAt() != null) {
            secondsLeft = Math.max(0, Duration.between(LocalDateTime.now(), b.getHoldExpiresAt()).getSeconds());
        }
        boolean cancellable = b.getStatus() == BookingStatus.CONFIRMED && !b.getTravelDate().isBefore(LocalDate.now());
        return new BookingDto(b.getId(), b.getPnr(), b.getStatus().name(),
                t.getTrainNumber(), t.getTrainName(),
                t.getSourceCode(), t.getSourceName() == null ? t.getSourceCode() : t.getSourceName(),
                t.getDestinationCode(), t.getDestinationName() == null ? t.getDestinationCode() : t.getDestinationName(),
                t.getDepartureTime(), t.getArrivalTime(), b.getTrainClass().getClassCode(),
                b.getTravelDate(), b.getSeatNumbers(), b.getPassengerName(),
                b.getSubtotal(), b.getServiceFee(), b.getTotalAmount(),
                b.getCreatedAt(), secondsLeft, b.getUser().getName(), b.getUser().getEmail(), cancellable);
    }

    private String newPnr() {
        String pnr;
        do {
            pnr = String.valueOf(1_000_000_000L + (long) (random.nextDouble() * 8_999_999_999L));
        } while (bookingRepository.existsByPnr(pnr));
        return pnr;
    }
}
