package com.dsu.ticketbooking.model;

import jakarta.persistence.*;
import java.math.BigDecimal;

/** A travel class of a train (SL, 3A, 2A, 1A, CC ...) with its fare and seat count. */
@Entity
@Table(name = "train_classes",
        uniqueConstraints = @UniqueConstraint(name = "uk_train_class", columnNames = {"train_id", "class_code"}))
public class TrainClass {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "train_id", nullable = false)
    private Train train;

    @Column(name = "class_code", nullable = false, length = 5)
    private String classCode;

    /** Fare per seat in rupees. */
    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal fare;

    @Column(name = "total_seats", nullable = false)
    private int totalSeats;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Train getTrain() { return train; }
    public void setTrain(Train train) { this.train = train; }
    public String getClassCode() { return classCode; }
    public void setClassCode(String classCode) { this.classCode = classCode; }
    public BigDecimal getFare() { return fare; }
    public void setFare(BigDecimal fare) { this.fare = fare; }
    public int getTotalSeats() { return totalSeats; }
    public void setTotalSeats(int totalSeats) { this.totalSeats = totalSeats; }
}
