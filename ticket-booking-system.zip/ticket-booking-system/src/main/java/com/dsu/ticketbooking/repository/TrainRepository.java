package com.dsu.ticketbooking.repository;

import com.dsu.ticketbooking.model.Train;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface TrainRepository extends JpaRepository<Train, Long> {

    Optional<Train> findByTrainNumber(String trainNumber);

    boolean existsByTrainNumber(String trainNumber);

    /** Matches a station by exact code (e.g. SBC) or by part of its name (e.g. "bengaluru"). */
    @Query("""
            select t from Train t
            where (lower(t.sourceCode) = lower(:from) or lower(t.sourceName) like lower(concat('%', :from, '%')))
              and (lower(t.destinationCode) = lower(:to) or lower(t.destinationName) like lower(concat('%', :to, '%')))
            order by t.departureTime
            """)
    List<Train> search(@Param("from") String from, @Param("to") String to);

    @Query("""
            select t from Train t
            where lower(t.trainNumber) like lower(concat('%', :q, '%'))
               or lower(t.trainName) like lower(concat('%', :q, '%'))
               or lower(t.sourceCode) = lower(:q) or lower(t.destinationCode) = lower(:q)
            order by t.trainNumber
            """)
    List<Train> adminSearch(@Param("q") String q, Pageable pageable);

    @Query("select t from Train t order by t.trainNumber")
    List<Train> findAllOrdered(Pageable pageable);

    @Query("select distinct t.sourceCode, t.sourceName from Train t")
    List<Object[]> findSourceStations();

    @Query("select distinct t.destinationCode, t.destinationName from Train t")
    List<Object[]> findDestinationStations();
}
