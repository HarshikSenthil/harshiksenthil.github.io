package com.dsu.ticketbooking.model;

public enum PaymentStatus {
    CREATED, SUCCESS, FAILED, REFUNDED
}
