package com.dsu.ticketbooking.model;

public enum BookingStatus {
    PENDING, CONFIRMED, CANCELLED, FAILED, EXPIRED
}
