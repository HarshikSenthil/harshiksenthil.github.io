package com.dsu.ticketbooking.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;

/** Calculates the amount payable: fare x seats + service fee. */
@Component
public class FareCalculator {

    public record FareBreakdown(BigDecimal subtotal, BigDecimal serviceFee, BigDecimal total) {
    }

    private final BigDecimal serviceFeePercent;

    public FareCalculator(@Value("${app.booking.service-fee-percent:2}") BigDecimal serviceFeePercent) {
        this.serviceFeePercent = serviceFeePercent;
    }

    public BigDecimal getServiceFeePercent() {
        return serviceFeePercent;
    }

    public FareBreakdown calculate(BigDecimal farePerSeat, int seats) {
        if (farePerSeat == null || farePerSeat.signum() < 0) {
            throw new IllegalArgumentException("Fare must be zero or more");
        }
        if (seats <= 0) {
            throw new IllegalArgumentException("At least one seat is required");
        }
        BigDecimal subtotal = farePerSeat.multiply(BigDecimal.valueOf(seats)).setScale(2, RoundingMode.HALF_UP);
        BigDecimal fee = subtotal.multiply(serviceFeePercent)
                .divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);
        return new FareBreakdown(subtotal, fee, subtotal.add(fee));
    }
}
