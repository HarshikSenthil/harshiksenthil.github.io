package com.dsu.ticketbooking.dto;

import jakarta.validation.constraints.*;

import java.math.BigDecimal;

public record ClassForm(
        @NotBlank(message = "is required") @Size(max = 5) String classCode,
        @NotNull(message = "is required") @DecimalMin(value = "0.0", message = "cannot be negative") BigDecimal fare,
        @NotNull(message = "is required") @Min(value = 1, message = "must be at least 1") @Max(value = 200, message = "must be at most 200") Integer totalSeats) {
}
