package com.dsu.ticketbooking.dto;

public record StationDto(String code, String name) {
}
