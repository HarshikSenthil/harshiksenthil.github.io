package com.dsu.ticketbooking.dto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

public record BookingDto(Long id, String pnr, String status,
                         String trainNumber, String trainName,
                         String sourceCode, String sourceName, String destinationCode, String destinationName,
                         String departureTime, String arrivalTime, String classCode,
                         LocalDate travelDate, String seatNumbers, String passengerName,
                         BigDecimal subtotal, BigDecimal serviceFee, BigDecimal totalAmount,
                         LocalDateTime createdAt, long holdSecondsRemaining,
                         String customerName, String customerEmail, boolean cancellable) {
}
