package com.dsu.ticketbooking.dto;

import java.math.BigDecimal;

/** available is null in admin listings (no travel date involved). */
public record ClassInfo(Long classId, String classCode, BigDecimal fare, int totalSeats, Integer available) {
}
