/* Shared helpers used by every page. */
const API = {
  async request(method, url, body) {
    const options = { method, headers: {}, credentials: 'same-origin' };
    if (body !== undefined) {
      options.headers['Content-Type'] = 'application/json';
      options.body = JSON.stringify(body);
    }
    const res = await fetch(url, options);
    if (res.status === 204) return null;
    const text = await res.text();
    let data = null;
    if (text) {
      try { data = JSON.parse(text); } catch (e) { data = { message: text }; }
    }
    if (!res.ok) {
      const error = new Error((data && data.message) || ('Request failed (' + res.status + ')'));
      error.status = res.status;
      throw error;
    }
    return data;
  },
  get(url) { return this.request('GET', url); },
  post(url, body) { return this.request('POST', url, body === undefined ? {} : body); },
  put(url, body) { return this.request('PUT', url, body === undefined ? {} : body); },
  del(url) { return this.request('DELETE', url); }
};

/** Escapes text before inserting it into HTML (prevents XSS). */
function esc(value) {
  return String(value === null || value === undefined ? '' : value)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function qs(name) { return new URLSearchParams(window.location.search).get(name); }

function money(n) {
  return '\u20B9' + Number(n || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function fmtDate(iso) {
  if (!iso) return '';
  const [y, m, d] = iso.split('-').map(Number);
  return new Date(y, m - 1, d).toLocaleDateString('en-IN', { weekday: 'short', day: '2-digit', month: 'short', year: 'numeric' });
}

function todayIso() {
  const d = new Date();
  d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
  return d.toISOString().slice(0, 10);
}

function statusBadge(status) {
  const colors = { CONFIRMED: 'success', PENDING: 'warning text-dark', CANCELLED: 'secondary', FAILED: 'danger', EXPIRED: 'dark' };
  return '<span class="badge bg-' + (colors[status] || 'secondary') + '">' + esc(status) + '</span>';
}

function showAlert(container, message, type) {
  const el = typeof container === 'string' ? document.getElementById(container) : container;
  if (!el) return;
  el.innerHTML = '<div class="alert alert-' + (type || 'danger') + ' alert-dismissible fade show" role="alert">'
    + esc(message) + '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>';
}

async function currentUser() {
  try { return await API.get('/api/auth/me'); } catch (e) { return null; }
}

function goToLogin() {
  window.location.href = 'login.html?next=' + encodeURIComponent(window.location.pathname + window.location.search);
}

/** Draws the top navigation bar and returns the logged-in user (or null). */
async function initPage() {
  const user = await currentUser();
  const nav = document.getElementById('nav');
  if (nav) {
    let links = '<li class="nav-item"><a class="nav-link" href="index.html">Search</a></li>';
    if (user) {
      links += '<li class="nav-item"><a class="nav-link" href="my-bookings.html">My Bookings</a></li>';
      if (user.role === 'ADMIN') links += '<li class="nav-item"><a class="nav-link" href="admin.html">Admin</a></li>';
      links += '<li class="nav-item"><span class="nav-link text-white-50">Hi, ' + esc(user.name.split(' ')[0]) + '</span></li>'
        + '<li class="nav-item"><a class="nav-link" href="#" id="logoutLink">Logout</a></li>';
    } else {
      links += '<li class="nav-item"><a class="nav-link" href="login.html">Login</a></li>'
        + '<li class="nav-item"><a class="nav-link" href="register.html">Register</a></li>';
    }
    nav.innerHTML =
      '<nav class="navbar navbar-expand-md navbar-dark"><div class="container">'
      + '<a class="navbar-brand" href="index.html">&#x1F686; TicketBook</a>'
      + '<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navLinks" aria-label="Menu"><span class="navbar-toggler-icon"></span></button>'
      + '<div class="collapse navbar-collapse" id="navLinks"><ul class="navbar-nav ms-auto">' + links + '</ul></div>'
      + '</div></nav>';
    const logout = document.getElementById('logoutLink');
    if (logout) {
      logout.addEventListener('click', async (e) => {
        e.preventDefault();
        await API.post('/api/auth/logout');
        window.location.href = 'index.html';
      });
    }
  }
  return user;
}
