# Test cases

Run the automated tests with `./mvnw test` (Windows: `mvnw.cmd test`). They use an in-memory H2 database,
so MySQL is not needed for testing. Fill in the **Actual / Status** columns after you run them yourself.

## Automated tests (JUnit)

| ID | Scenario | Input | Expected result | JUnit test | Actual / Status |
|---|---|---|---|---|---|
| UT01 | Fare calculation | Fare 500, 3 seats | Subtotal 1500, fee 30, total 1530 | FareCalculatorTest.calculatesTotal | |
| UT02 | Fee rounding | Fare 333.33, 1 seat | Fee 6.67, total 340.00 | FareCalculatorTest.roundsFee | |
| UT03 | Zero seats | 0 seats | Error | FareCalculatorTest.rejectsZeroSeats | |
| UT04 | Negative fare | Fare -1 | Error | FareCalculatorTest.rejectsNegativeFare | |
| TC01 | Register and log in | New email, password | Account created, password stored hashed, login works | AuthServiceTest.registerAndLogin | |
| TC02 | Invalid login | Wrong password | 401 "Invalid email or password" | AuthServiceTest.wrongPassword | |
| TC03 | Search tickets | Valid route and date | Trains listed with seats available | BookingFlowTest.searchWorks | |
| TC04 | Book and pay | 2 seats, successful payment | Booking CONFIRMED, seats BOOKED, payment SUCCESS | BookingFlowTest.bookAndPay | |
| TC05 | Double booking | Same seat booked by two users | Second attempt rejected (409), no seat left locked | BookingFlowTest.doubleBookingRejected | |
| TC06 | Payment failure | Declined test card | Booking FAILED, seats released | BookingFlowTest.failedPaymentReleasesSeats | |
| TC07 | Cancel booking | Confirmed booking | CANCELLED, seats released, payment REFUNDED | BookingFlowTest.cancelBooking | |
| TC09 | Duplicate email | Register same email twice | 409 conflict | AuthServiceTest.duplicateEmail | |
| TC10 | Past travel date | Yesterday's date | 400 error | BookingFlowTest.searchPastDate | |
| TC11 | Seat hold timeout | Booking not paid in time | Booking EXPIRED, seats released | BookingFlowTest.holdExpires | |
| TC12 | Too many seats | 7 seats | 400 error (max 6) | BookingFlowTest.tooManySeats | |
| TC13 | Access control | User opens another user's booking | 404, booking hidden | BookingFlowTest.cannotSeeOthersBooking | |
| ST01 | Start-up | App starts | Sample data and admin account loaded | TicketBookingApplicationTests | |

## Manual / UI tests

| ID | Scenario | Steps | Expected result | Actual / Status |
|---|---|---|---|---|
| TC08 | Empty form fields | Submit the register form blank | Validation message shown | |
| UI01 | Seat map | Open a class on a date that has bookings | Booked seats are grey and cannot be clicked | |
| UI02 | Hold countdown | Proceed to pay and wait | Timer counts down; after expiry payment is blocked | |
| UI03 | E-ticket | Pay successfully | Ticket with PNR shown, Print / Save as PDF works | |
| UI04 | Role-based access | Log in as demo user, open /admin.html | "Admin access only" | |
| UI05 | Admin edits fare | Change a class fare, save, search again | New fare shown in search results | |
| UI06 | Admin adds train | Add a train with one class | Train appears in search | |
| UI07 | Admin cannot delete booked train | Delete a train that has bookings | Error: train has bookings | |
| API01 | Unauthenticated booking | POST /api/bookings without login (Postman) | 401 | |
| SEC01 | SQL injection attempt | Login with email `' OR '1'='1` | Rejected; JPA uses parameterised queries | |

## Performance checks to record

| Metric | How to measure | Your value |
|---|---|---|
| Search response time | Browser DevTools, Network tab, `/api/trains/search` | |
| Time to complete one booking | Stopwatch from search to e-ticket | |
