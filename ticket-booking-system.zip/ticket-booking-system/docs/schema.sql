-- Reference schema (MySQL 8). Hibernate creates these tables automatically
-- (spring.jpa.hibernate.ddl-auto=update), so running this file is NOT required.

CREATE TABLE users (
  id            BIGINT AUTO_INCREMENT PRIMARY KEY,
  name          VARCHAR(100) NOT NULL,
  email         VARCHAR(150) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,          -- BCrypt hash
  role          VARCHAR(20)  NOT NULL,          -- CUSTOMER / ADMIN
  created_at    DATETIME(6)  NOT NULL
);

CREATE TABLE trains (
  id               BIGINT AUTO_INCREMENT PRIMARY KEY,
  train_number     VARCHAR(10)  NOT NULL UNIQUE,
  train_name       VARCHAR(120) NOT NULL,
  source_code      VARCHAR(10)  NOT NULL,
  source_name      VARCHAR(100),
  destination_code VARCHAR(10)  NOT NULL,
  destination_name VARCHAR(100),
  departure_time   VARCHAR(5),
  arrival_time     VARCHAR(5),
  duration         VARCHAR(20)
);

CREATE TABLE train_classes (
  id          BIGINT AUTO_INCREMENT PRIMARY KEY,
  train_id    BIGINT        NOT NULL,
  class_code  VARCHAR(5)    NOT NULL,           -- SL, 3A, 2A, 1A, CC, EC ...
  fare        DECIMAL(10,2) NOT NULL,
  total_seats INT           NOT NULL,
  CONSTRAINT uk_train_class UNIQUE (train_id, class_code),
  FOREIGN KEY (train_id) REFERENCES trains(id)
);

CREATE TABLE bookings (
  id              BIGINT AUTO_INCREMENT PRIMARY KEY,
  pnr             VARCHAR(10)   NOT NULL UNIQUE,
  user_id         BIGINT        NOT NULL,
  train_class_id  BIGINT        NOT NULL,
  travel_date     DATE          NOT NULL,
  passenger_name  VARCHAR(100)  NOT NULL,
  seat_numbers    VARCHAR(100)  NOT NULL,
  subtotal        DECIMAL(10,2) NOT NULL,
  service_fee     DECIMAL(10,2) NOT NULL,
  total_amount    DECIMAL(10,2) NOT NULL,
  status          VARCHAR(20)   NOT NULL,       -- PENDING / CONFIRMED / CANCELLED / FAILED / EXPIRED
  created_at      DATETIME(6)   NOT NULL,
  hold_expires_at DATETIME(6),
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (train_class_id) REFERENCES train_classes(id)
);

-- One row per seat per day. The UNIQUE key makes double booking impossible.
CREATE TABLE seat_reservations (
  id             BIGINT AUTO_INCREMENT PRIMARY KEY,
  train_class_id BIGINT      NOT NULL,
  travel_date    DATE        NOT NULL,
  seat_no        INT         NOT NULL,
  status         VARCHAR(10) NOT NULL,          -- LOCKED / BOOKED
  locked_until   DATETIME(6),
  booking_id     BIGINT      NOT NULL,
  CONSTRAINT uk_seat_per_day UNIQUE (train_class_id, travel_date, seat_no),
  FOREIGN KEY (train_class_id) REFERENCES train_classes(id),
  FOREIGN KEY (booking_id) REFERENCES bookings(id)
);

CREATE TABLE payments (
  id                  BIGINT AUTO_INCREMENT PRIMARY KEY,
  booking_id          BIGINT        NOT NULL,
  amount              DECIMAL(10,2) NOT NULL,
  status              VARCHAR(20)   NOT NULL,   -- CREATED / SUCCESS / FAILED / REFUNDED
  provider            VARCHAR(20)   NOT NULL,   -- MOCK / RAZORPAY
  provider_order_id   VARCHAR(60),
  provider_payment_id VARCHAR(60),
  created_at          DATETIME(6)   NOT NULL,
  FOREIGN KEY (booking_id) REFERENCES bookings(id)
);
